//
// Created by 孙奕can on 2023/7/14.
//

#ifndef DPSYN_KSOLVE_H
#define DPSYN_KSOLVE_H

#include "synth/example.h"
#include "synth/witness_syntheiszer.h"


void solve_benchmark(const ex_factory& exf, long double &tot_timer, long double& ded_timer);


#endif //DPSYN_KSOLVE_H
