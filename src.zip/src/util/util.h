//
// Created by gtw on 22-4-28.
//

#ifndef DPSYN_UTIL_H
#define DPSYN_UTIL_H

#include <cassert>

const int INF = 100000000;
const int IDEN_MAX = 25;
const int CASES_MAX = 1;
const int CoefRange = 2;
const int KMinClosure = 3;
const int KNumbersMax = 10;
const int KConstantRange = 0;
#define VAR_TO_VALUE(n) ((n) + INF)
#define VALUE_TO_VAR(n) ((n) - INF)
#define ISVAR(n) ((n) >= INF)
#define DEBUG 0
#define DEBUG2 (0 || DEBUG)
#define DEBUG4 (0 || DEBUG2)
#define DEBUG6 (0 || DEBUG4)

#endif //DPSYN_UTIL_H
