//
// Created by 孙奕can on 2022/6/7.
//

#include "knapsack.h"



example* Knapsack::generate() {
    int arr3[1005];
    std::default_random_engine ran1;
    memset(arr3, 0, sizeof arr3);

    auto Knapsack_new = new Knapsack(*this);
    int _n = 5;
    int _range = 20;

    std::uniform_int_distribution<int> u(-_range, _range);
    int _W = u(ran1);
    for(int i = 0; i < _n; i ++) {
        arr3[i] = u(ran1);
        Knapsack_new->update_env_list_par(a_id, i, arr3[i]);
    }
    Knapsack_new->update_env(n_id, _n);
    Knapsack_new->update_env(W_id, _W);
    Knapsack_new->concretize();
    return Knapsack_new;
}
