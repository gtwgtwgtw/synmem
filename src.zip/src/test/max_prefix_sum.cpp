//
// Created by 孙奕can on 2022/6/16.
//

#include "max_prefix_sum.h"

int a_max_sum[155];
std::default_random_engine ran_sum_max;


example* max_prefix_sum::generate() {
    set_type();
    auto sum_new = new max_prefix_sum(*this);
    sum_new->set_type();
    int _n = 8;
    int _range = 1;

    std::uniform_int_distribution<int> u(-_range, _range);
    int _w = u(ran_sum_max);
    for(int i = 0; i < _n; i ++) {
        a_max_sum[i] = u(ran_sum_max);
        sum_new->update_env_list_par(a_id, i, a_max_sum[i]);
    }

    sum_new->update_env(n_id, _n);
    sum_new->update_env(np1_id, _n - 1);
    sum_new->update_env(W_id, _w);
#if DEBUG
    fprintf(stderr, "[START CONCRETIZE]\n");
#endif
    sum_new->concretize();
#if DEBUG
    fprintf(stderr, "[END CONCRETIZE]\n");
#endif
    return sum_new;
}