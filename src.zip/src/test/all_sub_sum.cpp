//
// Created by 孙奕can on 2022/6/16.
//

#include "all_sub_sum.h"

int a_sum_sub[1005];
std::default_random_engine ran_suffix;

example* all_suffix_sum::generate() {
    set_type();
    auto sum_new = new all_suffix_sum(*this);
    sum_new->set_type();
    int _n = 8;
    int _range = 20;

    std::uniform_int_distribution<int> u(1, _range);
    for(int i = 0; i < _n; i ++) {
        a_sum_sub[i] = u(ran_suffix);
        //fprintf(stderr, "array(%d) = %d\n", i, a_sum_sub[i]);
        sum_new->update_env_list_par(a_id, i, a_sum_sub[i]);
    }

    sum_new->update_env(n_id, _n);
#if DEBUG
    fprintf(stderr, "[START CONCRETIZE]\n");
#endif
    sum_new->concretize();
#if DEBUG
    fprintf(stderr, "[END CONCRETIZE]\n");
#endif
    int sm = 0;
    for(int i = _n - 1; i >= 0; i --) {
        int cur = sum_new->env_list_lookup(b_id, i, 1);
#if DEBUG
        fprintf(stderr, "[GET_RESULT]%d\n", cur);
#endif
        sm += a_sum_sub[i];
        sum_new->update_domain(cur - INF, {sm, sm});
    }
    return sum_new;
}