//
// Created by 孙奕can on 2022/6/20.
//

#ifndef DPSYN_FIB_NUMBER_H
#define DPSYN_FIB_NUMBER_H


#include "../synth/example.h"

class fib_number: public example {
public:
    int x_id, n_id, i_id;
    fib_number() {
        n_id = new_parameter("n", {-INF, INF});
        x_id = new_var_list("x", n_id + INF, {0, 1});
        i_id = new_var("i", {-INF, INF});


        int add_op = string_to_op("Add");
        int sub_op = string_to_op("Sub");
        int eq_op = string_to_op("Equal");
        int or_op = string_to_op("Or");
        int call_value = string_to_op("Call_list_to_value");
        int call_var = string_to_op("Call_list_to_value_or_Var");

        auto* const2 = new constval(2);
        auto* const1 = new constval(1);
        auto* constn1 = new constval(-1);
        auto* var_i = new constval(i_id + INF);
        auto* var_n = new constval(n_id + INF);
        auto* var_x = new constval(x_id + INF);

        auto* np3 = new atom_term(sub_op, {var_n->deepcopy(), new constval(3)});
        auto* np1 = new atom_term(sub_op, {var_n->deepcopy(), new constval(1)});
        auto* x0 = new atom_term(call_var, {var_x->deepcopy(), new constval(0)});
        auto* xnp1 = new atom_term(call_var, {var_x->deepcopy(), np1->deepcopy()});
        auto* eqx0 = new atom_term(eq_op, {x0, new constval(1)});
        auto* eqxn = new atom_term(eq_op, {xnp1, new constval(1)});
        auto* ip1 = new atom_term(add_op, {var_i->deepcopy(), new constval(1)});
        auto* ip2 = new atom_term(add_op, {var_i->deepcopy(), new constval(2)});
        auto* xi = new atom_term(call_var, {var_x->deepcopy(), var_i->deepcopy()});
        auto* xip1 = new atom_term(call_var, {var_x->deepcopy(), ip1->deepcopy()});
        auto* xip2 = new atom_term(call_var, {var_x->deepcopy(), ip2->deepcopy()});
        auto* eqi = new atom_term(eq_op, {xi, new constval(0)});
        auto* eqip1 = new atom_term(eq_op, {xip1, new constval(1)});
        auto* eqip2 = new atom_term(eq_op, {xip2, new constval(1)});
        auto* vi = new atom_term(or_op, {eqi, eqip1});
        auto* vip2 = new atom_term(or_op, {vi, eqip2});
        auto* rdterm = new reduce_term(string_to_op("And"), new constval(0), np3, i_id, vip2);
        add_constraint(rdterm);
    }

    example* generate() override;
    enumerator * get_enumerator() const override;
};

#endif //DPSYN_FIB_NUMBER_H
