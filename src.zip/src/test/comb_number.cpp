//
// Created by 孙奕can on 2022/6/20.
//

#include "comb_number.h"

std::default_random_engine ran_comb;


example* comb_number::generate() {
    auto* nw = new comb_number(*this);
    int _range = 10;
    std::uniform_int_distribution<int> u(-_range, _range);
    int n = u(ran_comb), m = u(ran_comb);
    if(n < m)
        std::swap(n, m);
    nw->update_env(n_id, n);
    nw->update_env(m_id, m);
    nw->concretize();
    return nw;
}

enumerator* comb_number::get_enumerator() const {
    vector<object> u;
    u.emplace_back(HEAD, x_id);
    return new enumerator(nullptr, u);
}