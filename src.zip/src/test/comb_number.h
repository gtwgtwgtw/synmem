//
// Created by 孙奕can on 2022/6/20.
//

#ifndef DPSYN_COMB_NUMBER_H
#define DPSYN_COMB_NUMBER_H

#include "../synth/example.h"

class comb_number: public example {
public:
    int x_id, n_id, m_id, i_id;
    comb_number() {
        n_id = new_parameter("n", {-INF, INF});
        m_id = new_parameter("m", {-INF, INF});
        x_id = new_var_list("x", n_id + INF, {0, m_id + INF});
        i_id = new_var("i", {-INF, INF});


        int add_op = string_to_op("Add");
        int sub_op = string_to_op("Sub");
        int call_value = string_to_op("Call_list_to_value");
        int call_var = string_to_op("Call_list_to_value_or_Var");

        auto* const2 = new constval(2);
        auto* const1 = new constval(1);
        auto* constn1 = new constval(-1);
        auto* var_i = new constval(i_id + INF);
        auto* var_n = new constval(n_id + INF);
        auto* var_m = new constval(m_id + INF);
        auto* var_x = new constval(x_id + INF);

        auto* np2 = new atom_term(sub_op, {var_n->deepcopy(), const2->deepcopy()});
        auto* ip1 = new atom_term(add_op, {var_i->deepcopy(), const1});
        auto* xi = new atom_term(call_var, {var_x, var_i});
        auto* xip1 = new atom_term(call_var, {var_x->deepcopy(), ip1});
        auto* xn = new atom_term(call_var, {var_x->deepcopy(), var_n->deepcopy()});
        auto* x0 = new atom_term(call_var, {var_x->deepcopy(), new constval(0)});
        auto* eqxn = new atom_term(string_to_op("Equal"), {xn, var_m->deepcopy()});
        auto* eqx0 = new atom_term(string_to_op("Equal"), {x0, new constval(0)});
        auto* sub = new atom_term(sub_op, {xip1, xi});
        auto* le = new atom_term(string_to_op("Less"), {sub, const2->deepcopy()});
        auto* ge = new atom_term(string_to_op("Less"), {constn1, sub->deepcopy()});
        auto* body = new atom_term(string_to_op("And"), {le, ge});
        auto* rdterm = new reduce_term(string_to_op("And"), new constval(0), np2, i_id, body);

        add_constraint(rdterm);
        add_constraint(eqxn);
        add_constraint(eqx0);
    }

    example* generate() override;
    enumerator * get_enumerator() const override;
};

#endif //DPSYN_COMB_NUMBER_H
