//
// Created by 孙奕can on 2022/6/14.
//

#include "LCS.h"


example* LCS::generate() {
    auto LIS_new = new LCS(*this);
    int _n = 10;
    int _m = 5;
    int _range = 2;
    int idn, arr4[1005], arr5[1005];
    std::default_random_engine ran3;
    idn = 0;
    memset(arr4, 0, sizeof arr4);
    memset(arr5, 0, sizeof arr5);

    std::uniform_int_distribution<int> u(-_range, _range);
    for(int i = 0; i < _n; i ++) {
        arr4[i] = u(ran3);
        arr5[i] = u(ran3);
        LIS_new->update_env_list_par(a_id, i + 1, arr4[i]);
        LIS_new->update_env_list_par(b_id, i + 1, arr5[i]);
    }

    LIS_new->update_env(n_id, _n);
    LIS_new->update_env(m_id, _m);
    LIS_new->concretize();
    return LIS_new;
}

enumerator* LCS::get_enumerator() const {
    vector<object> u;
    u.emplace_back(make_pair(HEAD, 5));
    u.emplace_back(make_pair(HEAD, 6));
    return new enumerator(nullptr, u);
}