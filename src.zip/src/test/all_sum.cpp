//
// Created by 孙奕can on 2022/6/16.
//

#include "all_sum.h"

int a_sum[1005], b_sum[1005];
std::default_random_engine ran_sum;

example* all_prefix_sum::generate() {
    set_type();
    auto sum_new = new all_prefix_sum(*this);
    sum_new->set_type();
    int _n = 8;
    int _range = 20;

    std::uniform_int_distribution<int> u(-_range, _range);
    for(int i = 0; i < _n; i ++) {
        a_sum[i] = u(ran_sum);
        sum_new->update_env_list_par(a_id, i, a_sum[i]);
    }

    sum_new->update_env(n_id, _n);
#if DEBUG
    fprintf(stderr, "[START CONCRETIZE]\n");
#endif
    sum_new->concretize();
#if DEBUG
    fprintf(stderr, "[END CONCRETIZE]\n");
#endif
    int sm = 0;
    for(int i = 0; i < _n; i ++) {
        int cur = sum_new->env_list_lookup(b_id, i, 1);
#if DEBUG
        fprintf(stderr, "[GET_RESULT]%d\n", cur);
#endif
        sm += a_sum[i];
        sum_new->update_domain(cur - INF, {sm, sm});
    }
    return sum_new;
}