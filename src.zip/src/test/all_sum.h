//
// Created by 孙奕can on 2022/6/16.
//

#ifndef DPSYN_ALL_SUM_H
#define DPSYN_ALL_SUM_H

#include "../synth/example.h"

class all_prefix_sum: public example {
public:
    int n_id, a_id, b_id;
    all_prefix_sum() {
        int i_id, j_id;
        constval* var_n_id;
        constval* var_a_id;
        constval* var_i_id;
        constval* var_b_id;
        constval* var_j_id;
        atom_term* aj;
        atom_term* bi;
        atom_term* np1;
        atom_term* ip1;
        term* body;
        reduce_term* rdterm;
        reduce_term* constraint;

        int add_op = string_to_op("Add");
        int sub_op = string_to_op("Sub");
        int eq_op = string_to_op("Equal");
        int call_value = string_to_op("Call_list_to_value");
        int call_var = string_to_op("Call_list_to_value_or_Var");

        n_id = new_parameter("n", make_pair(1, INF));
        a_id = new_parameter_list("a", n_id + INF, make_pair(-INF, INF));
        i_id = new_var("i", {1, n_id + INF});
        j_id = new_var("j", {1, n_id + INF});
        b_id = new_var_list("b", n_id + INF, {0, 0});

        auto* const0 = new constval(0);
        auto* const1 = new constval(1);
        var_a_id = new constval(a_id + INF);
        var_b_id = new constval(b_id + INF);
        var_i_id = new constval(i_id + INF);
        var_n_id = new constval(n_id + INF);
        var_j_id = new constval(j_id + INF);
        aj = new atom_term(call_value, {var_a_id, var_j_id});
        bi = new atom_term(call_var, {var_b_id, var_i_id});
        np1 = new atom_term(sub_op, {var_n_id->deepcopy(), const1});
        rdterm = new reduce_term(add_op, const0, var_i_id->deepcopy(), j_id, aj);
        auto* eq_tm = new atom_term(eq_op, {rdterm, bi});
        constraint = new reduce_term(string_to_op("And"), const0, np1, i_id, eq_tm);

//	rdterm->print();
#if DEBUG
        rdterm->get_body()->print(); std::cerr << std::endl;
	std::cerr << rdterm->get_range_var() << std::endl;
#endif
        add_constraint(constraint);
        set_type();
    }

    all_prefix_sum(const all_prefix_sum& a) = default;
    all_prefix_sum(all_prefix_sum&& a) = default;
    ~all_prefix_sum() override = default;

    example* generate() override;
    enumerator* get_enumerator() const override {
        vector<object> u;
        u.emplace_back(HEAD, b_id);
        return new enumerator(nullptr, u);
    }
};

#endif //DPSYN_ALL_SUM_H
