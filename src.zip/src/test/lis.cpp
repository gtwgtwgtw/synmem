//
// Created by gtw on 22-5-6.
//

#include "lis.h"


example* LIS::generate() {
	auto LIS_new = new LIS(*this);
	int _n = 10;
	int _m = 3;
	int _range = 10;
    int n, arr6[1005];
    std::default_random_engine ran4;
    n = 0;
    memset(arr6, 0, sizeof arr6);

    std::uniform_int_distribution<int> u(-_range, _range);
	for(int i = 0; i < _n; i ++) {
        arr6[i] = u(ran4);
		LIS_new->update_env_list_par(a_id, i + 1, arr6[i]);
	}

	LIS_new->update_env(n_id, _n);
	LIS_new->update_env(m_id, _m);
	LIS_new->concretize();
	return LIS_new;
}
