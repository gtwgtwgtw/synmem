//
// Created by 孙奕can on 2022/6/14.
//

#ifndef DPSYN_KNAP2_H
#define DPSYN_KNAP2_H

#include "../synth/example.h"

class Knapsack2: public example {
public:
    int n_id, a_id, c_id, W_id, W2_id;
    Knapsack2() {
        int i_id, b_id;
        constval* const1;
        constval* var_n_id;
        constval* var_W_id;
        constval* var_W2_id;
        constval* var_c_id;
        constval* var_a_id;
        constval* var_i_id;
        constval* var_b_id;
        atom_term* ai;
        atom_term* bi;
        atom_term* np1;
        term* body;
        reduce_term* rdterm;
        term* constraint;

        int mult_op = string_to_op("Mult");
        int add_op = string_to_op("Add");
        int call_value = string_to_op("Call_list_to_value");
        int call_var = string_to_op("Call_list_to_value_or_Var");

        n_id = new_parameter("n", make_pair(1, INF));
        a_id = new_parameter_list("a", n_id + INF, make_pair(-INF, INF));
        c_id = new_parameter_list("a2", n_id + INF, make_pair(-INF, INF));
        W_id = new_parameter("W", {-INF, INF});
        W2_id = new_parameter("W2", {-INF, INF});
        i_id = new_var("i", {1, n_id + INF});
        b_id = new_var_list("b", n_id + INF, {0, 1});

        auto* const0 = new constval(0);
        const1 = new constval(1);
        var_a_id = new constval(a_id + INF);
        var_c_id = new constval(c_id + INF);
        var_b_id = new constval(b_id + INF);
        var_i_id = new constval(i_id + INF);
        var_n_id = new constval(n_id + INF);
        var_W_id = new constval(W_id + INF);
        var_W2_id = new constval(W2_id + INF);

        ai = new atom_term(call_value, {var_a_id, var_i_id});
        bi = new atom_term(call_var, {var_b_id, var_i_id->deepcopy()});
        auto ci = new atom_term(call_value, {var_c_id, var_i_id->deepcopy()});
        body = new atom_term(mult_op, {ai, bi});
        auto body2 = new atom_term(mult_op, {ci, bi->deepcopy()});
        np1 = new atom_term(string_to_op("Sub"), {var_n_id->deepcopy(), const1->deepcopy()});
        rdterm = new reduce_term(add_op, const0, np1, i_id, body);
        auto* rdterm2 = new reduce_term(add_op, const0->deepcopy(), np1->deepcopy(), i_id, body2);
        constraint = new atom_term(string_to_op("Equal"), {rdterm, var_W_id});
        auto constraint2 = new atom_term(string_to_op("Equal"), {rdterm2, var_W2_id});

        add_constraint(constraint);
        add_constraint(constraint2);
    }

    Knapsack2(const Knapsack2& a) = default;
    Knapsack2(Knapsack2&& a) = default;
    ~Knapsack2() override = default;

    example* generate() override;
    enumerator* get_enumerator() const override {
        vector<object> u;
        u.emplace_back(HEAD, 6);
        return new enumerator(nullptr, u);
    }
} ;


#endif //DPSYN_KNAP2_H
