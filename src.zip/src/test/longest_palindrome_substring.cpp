//
// Created by 孙奕can on 2022/6/17.
//

#include "longest_palindrome_substring.h"

int a_lps[1005];
std::default_random_engine ran_lps;

example* lp_sub::generate() {
    set_type();
    auto sum_new = new lp_sub(*this);
    sum_new->set_type();
    int _n = 20;
    int _range = 1;

    std::uniform_int_distribution<int> u(-_range, _range);
    for(int i = 0; i < _n; i ++) {
        a_lps[i] = u(ran_lps);
        sum_new->update_env_list_par(a_id, i, a_lps[i]);
    }

    sum_new->update_env(n_id, _n);
    sum_new->update_env(np1_id, _n - 1);
#if DEBUG
    fprintf(stderr, "[START CONCRETIZE]\n");
#endif
    sum_new->concretize();
#if DEBUG
    fprintf(stderr, "[END CONCRETIZE]\n");
#endif
    return sum_new;
}