//
// Created by gtw on 22-5-17.
//

#ifndef DPSYN_LIS_H
#define DPSYN_LIS_H

#include "../synth/example.h"
#include <iostream>
using std::pair;
using std::make_pair;
using std::cerr;

class LIS: public example {
	int n_id, a_id, m_id;
public:
	LIS() {
		int b_id, i_id;
		term* const_2;
		term* const_1;
		term* const_0;
		term* var_a_id;
		term* var_b_id;
		term* var_i_id;
		term* var_i_idp1;
		term* var_m_id;
		term* var_m_idm2;
		term* bi;
		term* bip1;
		term* abi;
		term* abip1;
		term* rel1;
		term* rel2;
		term* rel3;
		reduce_term* rdterm;
		
		n_id = new_parameter("n", make_pair(1, INF));
		a_id = new_parameter_list("a", n_id + INF, make_pair(-INF, INF));
		m_id = new_parameter("m", make_pair(1, VAR_TO_VALUE(n_id)));
		b_id = new_var_list("b", m_id + INF, make_pair(1, VAR_TO_VALUE(n_id)));
		i_id = new_var("i", make_pair(-INF, INF));
		const_2 = new constval(2);
		const_1 = new constval(1);
		const_0 = new constval(0);
		var_a_id = new constval(a_id + INF);
		var_b_id = new constval(b_id + INF);
		var_i_id = new constval(i_id + INF);
		var_m_id = new constval(m_id + INF);
		var_i_idp1 = new atom_term(string_to_op("Add"), {var_i_id, const_1});
		var_m_idm2 = new atom_term(string_to_op("Sub"), {var_m_id, const_2});
		bi = new atom_term(string_to_op("Call_list_to_value_or_Var"), {var_b_id, var_i_id->deepcopy()});
		bip1 = new atom_term(string_to_op("Call_list_to_value_or_Var"), {var_b_id->deepcopy(), var_i_idp1});
		abi = new atom_term(string_to_op("Call_list_to_value"), {var_a_id, bi});
		abip1 = new atom_term(string_to_op("Call_list_to_value"), {var_a_id->deepcopy(), bip1});
		rel1 = new atom_term(string_to_op("Less"), {bi->deepcopy(), bip1->deepcopy()});
		rel2 = new atom_term(string_to_op("Less"), {abi, abip1});
		rel3 = new atom_term(string_to_op("And"), {rel1, rel2});
		rdterm = new reduce_term(string_to_op("And"),
								 const_0, var_m_idm2, i_id, rel3);

		add_constraint(rdterm);
	}
	
	LIS(const LIS& a) = default;
	LIS(LIS&& a) = default;
	~LIS() override = default;
	
	example* generate() override;
    enumerator* get_enumerator() const override {
        vector<object> u;
        u.emplace_back(HEAD, 3);
        return new enumerator(nullptr, u);
    }
} ;


#endif //DPSYN_LIS_H
