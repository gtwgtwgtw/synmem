//
// Created by 孙奕can on 2022/6/17.
//

#ifndef DPSYN_LONGEST_PALINDROME_SUBSTRING_H
#define DPSYN_LONGEST_PALINDROME_SUBSTRING_H
#include "../synth/example.h"

class lp_sub: public example {
public:
    int n_id, np1_id, a_id, W_id, b_id;
    lp_sub() {
        int j_id;
        constval* var_n_id;
        constval* var_a_id;
        constval* var_b_id;
        constval* var_j_id;
        constval* var_W_id;
        atom_term* aj;
        reduce_term* rdterm;

        int add_op = string_to_op("Add");
        int sub_op = string_to_op("Sub");
        int eq_op = string_to_op("Equal");
        int call_value = string_to_op("Call_list_to_value");
        int call_var = string_to_op("Call_list_to_value_or_Var");

        n_id = new_parameter("n", make_pair(1, INF));
        np1_id = new_parameter("np1", {-INF, INF});
        a_id = new_parameter_list("a", n_id + INF, make_pair(-INF, INF));
        W_id = new_var("W", {1, n_id + INF});
        j_id = new_var("j", {1, n_id + INF});
        b_id = new_var("b", {0, np1_id + INF});
        auto* var_np1_id = new constval(np1_id + INF);

        //i == 1..W
        //b + i - 1
        //b + W - i
        //b + i, b - i
        auto* const0 = new constval(0);
        auto* const1 = new constval(1);
        var_a_id = new constval(a_id + INF);
        var_b_id = new constval(b_id + INF);
        var_W_id = new constval(W_id + INF);
        var_j_id = new constval(j_id + INF);
        var_n_id = new constval(n_id + INF);

        auto* v1 = new atom_term(add_op, {var_j_id->deepcopy(), var_b_id->deepcopy()});
        auto* v2 = new atom_term(sub_op, {v1, const1->deepcopy()});
        auto* v3 = new atom_term(add_op, {var_b_id->deepcopy(), var_W_id->deepcopy()});
        auto* v4 = new atom_term(sub_op, {v3, var_j_id->deepcopy()});
        auto* v5 = new atom_term(add_op, {var_W_id->deepcopy(), var_b_id->deepcopy()});
        auto* v7 = new atom_term(add_op, {var_n_id->deepcopy(), const1->deepcopy()});
        auto* v6 = new atom_term(string_to_op("Less"), {v5, v7});
        auto* v8 = new atom_term(string_to_op("Div"), {var_W_id->deepcopy(), new constval(2)});

        aj = new atom_term(call_value, {var_a_id, v2});
        auto* ak = new atom_term(call_value, {var_a_id->deepcopy(), v4});
        auto* body = new atom_term(eq_op, {aj, ak});
        rdterm = new reduce_term(string_to_op("And"), const1->deepcopy(), v8, j_id, body);

//	rdterm->print();
#if DEBUG
        rdterm->get_body()->print(); std::cerr << std::endl;
        std::cerr << rdterm->get_range_var() << std::endl;
#endif
        add_constraint(v6);
        add_constraint(rdterm);

        set_type();
    }

    lp_sub(const lp_sub& a) = default;
    lp_sub(lp_sub&& a) = default;
    ~lp_sub() override = default;

    example* generate() override;
    enumerator* get_enumerator() const override {
        vector<object> u, v;
        u.emplace_back(HEAD, b_id);
        v.emplace_back(HEAD, W_id);
        auto* x = new enumerator(nullptr, v);
        return new enumerator(x, u);
    }
};

#endif //DPSYN_LONGEST_PALINDROME_SUBSTRING_H
