//
// Created by 孙奕can on 2022/6/20.
//

#include "fib_number.h"



example* fib_number::generate() {
    std::default_random_engine ran2;
    auto* nw = new fib_number(*this);
    int n = 10;
    nw->update_env(n_id, n);
    nw->concretize();
    return nw;
}

enumerator* fib_number::get_enumerator() const {
    vector<object> u;
    u.emplace_back(HEAD, x_id);
    return new enumerator(nullptr, u);
}