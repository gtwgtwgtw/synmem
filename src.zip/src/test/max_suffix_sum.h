//
// Created by 孙奕can on 2022/6/16.
//

#ifndef DPSYN_MAX_SUFFIX_SUM_H
#define DPSYN_MAX_SUFFIX_SUM_H

#include "../synth/example.h"

class max_suffix_sum: public example {
public:
    int n_id, np1_id, a_id, W_id, b_id;
    max_suffix_sum() {
        int j_id;
        constval* var_n_id;
        constval* var_a_id;
        constval* var_b_id;
        constval* var_j_id;
        constval* var_W_id;
        atom_term* aj;
        reduce_term* rdterm;

        int add_op = string_to_op("Add");
        int sub_op = string_to_op("Sub");
        int eq_op = string_to_op("Equal");
        int call_value = string_to_op("Call_list_to_value");
        int call_var = string_to_op("Call_list_to_value_or_Var");

        n_id = new_parameter("n", make_pair(1, INF));
        np1_id = new_parameter("np1", {-INF, INF});
        a_id = new_parameter_list("a", n_id + INF, make_pair(-INF, INF));
        W_id = new_parameter("W", {-INF, INF});
        j_id = new_var("j", {1, n_id + INF});
        b_id = new_var("b", {0, np1_id + INF});
        auto* var_np1_id = new constval(np1_id + INF);

        auto* const0 = new constval(0);
        var_a_id = new constval(a_id + INF);
        var_b_id = new constval(b_id + INF);
        var_W_id = new constval(W_id + INF);
        var_j_id = new constval(j_id + INF);
        aj = new atom_term(call_value, {var_a_id, var_j_id});
        rdterm = new reduce_term(add_op, var_b_id->deepcopy(), var_np1_id->deepcopy(), j_id, aj);
        auto* eq_tm = new atom_term(eq_op, {rdterm, var_W_id});

//	rdterm->print();
#if DEBUG
        rdterm->get_body()->print(); std::cerr << std::endl;
        std::cerr << rdterm->get_range_var() << std::endl;
#endif
        add_constraint(eq_tm);
        set_type();
    }

    max_suffix_sum(const max_suffix_sum& a) = default;
    max_suffix_sum(max_suffix_sum&& a) = default;
    ~max_suffix_sum() override = default;

    example* generate() override;
    enumerator* get_enumerator() const override {
        vector<object> u;
        u.emplace_back(HEAD, b_id);
        return new enumerator(nullptr, u);
    }
};


#endif //DPSYN_MAX_PREFIX_SUM_H
