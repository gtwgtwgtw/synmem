//
// Created by 孙奕can on 2022/6/14.
//

#include "Knap2.h"




example *Knapsack2::generate() {
    auto Knapsack2_new = new Knapsack2(*this);
    int _n = 5;
    int _range = 20;
    int arr0[1005], arr1[1005];
    std::default_random_engine ran0;
    memset(arr0, 0, sizeof arr0);
    memset(arr1, 0, sizeof arr1);

    std::uniform_int_distribution<int> u(-_range, _range);
    int _W = u(ran0);
    int _W2 = u(ran0);
    for(int i = 0; i < _n; i ++) {
        arr0[i] = u(ran0);
        Knapsack2_new->update_env_list_par(a_id, i, arr0[i]);
        arr1[i] = u(ran0);
        Knapsack2_new->update_env_list_par(c_id, i, arr1[i]);
    }

    Knapsack2_new->update_env(n_id, _n);
    Knapsack2_new->update_env(W_id, _W);
    Knapsack2_new->update_env(W2_id, _W2);
    Knapsack2_new->concretize();
    return Knapsack2_new;
}
