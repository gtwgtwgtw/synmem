//
// Created by 孙奕can on 2022/6/17.
//

#include "max_suffix_sum.h"
int ax_max_sum[155];
std::default_random_engine ran_sum_cc;


example* max_suffix_sum::generate() {
    set_type();
    auto sum_new = new max_suffix_sum(*this);
    sum_new->set_type();
    int _n = 8;
    int _range = 1;

    std::uniform_int_distribution<int> u(-_range, _range);
    int _w = u(ran_sum_cc);
    for(int i = 0; i < _n; i ++) {
        ax_max_sum[i] = u(ran_sum_cc);
        sum_new->update_env_list_par(a_id, i, ax_max_sum[i]);
    }

    sum_new->update_env(n_id, _n);
    sum_new->update_env(np1_id, _n - 1);
    sum_new->update_env(W_id, _w);
#if DEBUG
    fprintf(stderr, "[START CONCRETIZE]\n");
#endif
    sum_new->concretize();
#if DEBUG
    fprintf(stderr, "[END CONCRETIZE]\n");
#endif
    return sum_new;
}