//
// Created by 孙奕can on 2022/6/14.
//

#ifndef DPSYN_LCS_H
#define DPSYN_LCS_H
#include "../synth/example.h"

class LCS: public example {
    int a_id, b_id, n_id, m_id;
public:
    LCS() {
        n_id = new_parameter("n", {-INF, INF});
        m_id = new_parameter("m", {1, n_id + INF});
        a_id = new_parameter_list("a", n_id + INF, {-INF, INF});
        b_id = new_parameter_list("b", n_id + INF, {-INF, INF});
        int i_id = new_var("i", {-INF, INF});
        int x_id = new_var_list("x", m_id + INF, {1, n_id + INF});
        int y_id = new_var_list("y", m_id + INF, {1, n_id + INF});
        int sub_op = string_to_op("Sub");
        int add_op = string_to_op("Add");
        int less_op = string_to_op("Less");
        int and_op = string_to_op("And");
        int call_var_op = string_to_op("Call_list_to_value_or_Var");
        int call_param_op = string_to_op("Call_list_to_value");
        int eq_op = string_to_op("Equal");

        auto* const0 = new constval(0);
        auto* const1 = new constval(1);
        auto* const2 = new constval(2);
        auto* var_i_id = new constval(i_id + INF);
        auto* var_n_id = new constval(n_id + INF);
        auto* var_m_id = new constval(m_id + INF);
        auto* var_x_id = new constval(x_id + INF);
        auto* var_y_id = new constval(y_id + INF);
        auto* var_a_id = new constval(a_id + INF);
        auto* var_b_id = new constval(b_id + INF);
        auto* ip1 = new atom_term(add_op, {var_i_id->deepcopy(), const1->deepcopy()});
        auto* mp1 = new atom_term(sub_op, {var_m_id->deepcopy(), const1});
        auto* mp2 = new atom_term(sub_op, {var_m_id->deepcopy(), const2});
        auto* body4 = new atom_term(call_var_op, {var_x_id->deepcopy(), var_i_id->deepcopy()});
        auto* body5 = new atom_term(call_var_op, {var_x_id->deepcopy(), ip1->deepcopy()});
        auto* body6 = new atom_term(call_var_op, {var_y_id->deepcopy(), var_i_id->deepcopy()});
        auto* body7 = new atom_term(call_var_op, {var_y_id->deepcopy(), ip1->deepcopy()});
        auto* body3 = new atom_term(less_op, {body6, body7});
        auto* body2 = new atom_term(less_op, {body4, body5});
        auto* body1 = new atom_term(and_op, {body2, body3});
        auto* rdterm1 = new reduce_term(and_op, const0->deepcopy(), mp2->deepcopy(), i_id, body1);
        auto* body8 = new atom_term(call_param_op, {var_a_id, body4->deepcopy()});
        auto* body9 = new atom_term(call_param_op, {var_b_id, body6->deepcopy()});
        auto* body10 = new atom_term(eq_op, {body8, body9});
        auto* rdterm2 = new reduce_term(and_op, const0->deepcopy(), mp1->deepcopy(), i_id, body10);

        add_constraint(rdterm1);
        add_constraint(rdterm2);
        upd_overhead(3);
    }

    example * generate() override;
    enumerator * get_enumerator() const override;
};

#endif //DPSYN_LCS_H
