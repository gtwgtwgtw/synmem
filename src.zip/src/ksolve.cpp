//
// Created by 孙奕can on 2023/7/14.
//

#include "ksolve.h"

void solve_single(example* meta_problem, long double& tot_timer, long double& ded_timer) {
    int overhead = meta_problem -> get_overhead();
    synthesis_clear();

    clock_t start, end;
    start = clock();
    long double timer = 0, ded_time = 0;
    auto* e = meta_problem->get_enumerator();
    //meta_problem->set_type();
    base_solver b = base_solver(meta_problem);
    witness_solver w;
    b.update_enum(e);
    w.set_meta(meta_problem);

    int cases = meta_problem->get_type() ? 5: 1;
    for(int i = 0; i < cases; i ++) {
        example_info info;
        computation_info cinfo;
        info.clear();
#if DEBUG
        fprintf(stderr, "[GENERATE TRACE %d]\n", i);
#endif
        auto t = b.generate_trace(info, cinfo);
        std::stable_sort(info.begin(), info.end());
#if DEBUG2
        fprintf(stderr, "begin\n");
        for(const auto& path: info) {
            path.print();
        }
        fprintf(stderr, "end\n");
#endif
        w.add_info(info, cinfo, t.first, t.second);
    }

    w.solve(ded_time);
    end = clock();
    timer = double(end - start);
    timer = timer * overhead;
    ded_time = ded_time * overhead;
    tot_timer += timer;
    ded_timer += ded_time;
}

void solve_benchmark(const ex_factory& exf, long double& tot_timer, long double& ded_timer) {
    bool first = true;
    for (auto p_single_flag: exf) {
        example* single = p_single_flag.ex;
        bool is_opt = p_single_flag.is_opt;
        if(is_opt) puts("[Local Objective Function]"); else {
            if(first) puts("[Memoization Partition Function]");
            first = false;
        }
        solve_single(single, tot_timer, ded_timer);
    }
}