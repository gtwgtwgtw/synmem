#include <iostream>
#include "synth/enum_solver.h"
#include "synth/witness_syntheiszer.h"
#include "ksolve.h"
#include "../benchmarks/select.h"

long double get_time_tp(timespec& tp) {
    return tp.tv_sec * 1e9 + tp.tv_nsec * 1e-9;
}

int main(int argc, char** argv) {
    long double timer = 0, ded_timer = 0;
    ex_factory model = select_benchmark("my" + string(argv[1]));
    solve_benchmark(model, timer, ded_timer);
    puts("[Runtime]");
    printf("total runtime = %.3Lf (sec)\n", timer / 1000000.);
    printf("deductive runtime = %.3Lf (sec)\n", ded_timer / 1000000.);
    return 0;
}
