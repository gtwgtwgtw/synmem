//
// Created by gtw on 22-5-5.
//

#include <iostream>
#include "semantics.h"


semantics const* op_to_semantics(int u) {
    static semantics* mult = new Mult;
    static semantics* div = new Div;
    static semantics* Or = new opOr;
	static semantics* op_lookup[] = {new Add, new Sub, new Less, new And, new Greater, new Equal, new Call(1), new Call(2), new Call(3), new Call(4)};
    if(u == -1)
        return mult;
    if(u == -2)
        return div;
    if(u == -3)
        return Or;
	return op_lookup[u];
}

string op_to_string(int u) {
	switch (u) {
        case -3: return "Or";
        case -2: return "Div";
        case -1: return "Mult";
		case 0: return "Add";
		case 1: return "Sub";
		case 2: return "Less";
		case 3: return "And";
		case 4: return "Greater";
		case 5: return "Equal";
		case 6: return "Call_list_to_value_or_Var";
		case 7: return "Call_list_to_list";
		case 8: return "Call_list_to_value";
		case 9: return "Call_list_to_range";
		default: return "";
	}
}

int string_to_op(const string& u) {
    if(u == "Or") return -3;
    if(u == "Div") return -2;
    if(u == "Mult") return -1;
	if(u == "Add") return 0;
	if(u == "Sub") return 1;
	if(u == "Less") return 2;
	if(u == "And") return 3;
	if(u == "Greater") return 4;
	if(u == "Equal") return 5;
	if(u == "Call_list_to_value_or_Var") return 6;
	if(u == "Call_list_to_list") return 7;
	if(u == "Call_list_to_value") return 8;
	if(u == "Call_list_to_range") return 9;
	return -INF;
}


term* constval::simplify(const env* e) {
//	std::cerr << "current = "; print(); std::cerr << std::endl;
	
	if(ISVAR(value)) {
		int nvalue = e->lookup(VALUE_TO_VAR(value));
//		std::cerr << "query " << value << " " << nvalue << std::endl;
		if(nvalue == -INF)
			return this;
		return new constval(nvalue);
	}
	return this;
}


term* atom_term::simplify(const env* e) {
	vector<term*> new_ops;
	vector<int> tmp;
#if DEBUG
	std::cerr << "current = "; print(); std::cerr << std::endl;
#endif
	int all_simplifed = 1;
	
	for(int i = 0; i < oprands.size(); i ++) {
		auto u = oprands[i];
		term* sub = u->simplify(e);
		new_ops.push_back(sub);
		if(sub->is_const()) {
			auto sub_const = static_cast<const constval*>(sub);
			int value = sub_const->get_value();
			if(f_op >= 6 && i == 0 && value >= INF) {
				tmp.push_back(value - INF);
			} else if(value != -INF && value < INF) {
				tmp.push_back(value);
			} else {
				all_simplifed = 0;
			}
		} else {
			all_simplifed = 0;
		}
	}
	
	oprands.clear();
	if(all_simplifed) {
#if DEBUG
		fprintf(stderr, "%s ", op_to_string(f_op).c_str());
		for(const auto&u: tmp) fprintf(stderr, "%d ", u);
		std::cerr << std::endl;
#endif
		for(auto u: oprands) delete u;
		oprands.clear();
		semantics const* op_semantic = op_to_semantics(f_op);
		term* nn = op_semantic->evaluate(tmp, e);
#if DEBUG
		std::cerr << "end = "; nn->print();  std::cerr << std::endl;
#endif
		return nn;
	} else {
		for(const auto&u: new_ops) oprands.push_back(u);
#if DEBUG
		std::cerr << "fail end = "; print(); std::cerr << std::endl;
#endif
		return this;
	}
}

vector<term*> reduce_term::transform(env *e) const {
	term* func_l = func_range_l->deepcopy()->simplify(e);
	term* func_r = func_range_r->deepcopy()->simplify(e);
	if(func_l->is_const() && func_r->is_const()) {
		int l = static_cast<constval*>(func_l)->get_value();
		int r = static_cast<constval*>(func_r)->get_value();
        if(l >= INF || r >= INF) {
            delete func_l;
            delete func_r;
            return {};
        }
#if DEBUG
        fprintf(stderr, "[L, R is constant now] = %d, %d\n", l, r);
#endif
		
		vector<term *> ans;
		ans.clear();
		e->update_value(range_var, -INF);
		for (int i = l; i <= r; i ++) {
			e->update_value(range_var, i);
			term *body = get_body();
			body = body->simplify(e);
			ans.push_back(body);
		}
		e->update_value(range_var, -INF);
        delete func_l;
        delete func_r;
		return ans;
	} else {
        delete func_l;
        delete func_r;
		return {};
	}
}

term* reduce_term::simplify(const env *e) {
#if DEBUG
    fprintf(stderr, "[simplify reduce term, FLATTENED] = %d\n", flatten_body);
#endif
    if(flatten_body) {
        int res = 0;
        for(int i = 0 ; i < bodies.size(); i ++) {
            bodies[i]->simplify(e);
            if(bodies[i]->is_const()) {
                int value = static_cast<constval*>(bodies[i])->get_value();
                if(value < INF) {
                    res += value;
                    bodies[i] = new constval(value);
                }
            }
        }
        return this;
    }
    env* e2 = new env(*e);
    const vector<term*>& m_bodies = transform(e2);
    if(! m_bodies.empty()){
        for(const auto& tm: m_bodies)
            bodies.push_back(tm);
        flatten_body = true;
    }
    delete e2;
    return this;
}

void constval::print() const {
	if(ISVAR(value))
		std::cerr << "var" << value - INF;
	else
		std::cerr << value;
}

void atom_term::print() const {
	if(oprands.empty()) {
		std::cerr << "";
		return;
	}
	std::cerr << op_to_string(f_op);
	std::cerr << "(";
	auto u = oprands.begin();
	(*u)->print();
	while (true) {
		u ++;
		if(u == oprands.end())
			break;
		std::cerr << ",";
		(*u)->print();
	}
	std::cerr << ")";
}

void reduce_term::print()  const {
    if(flatten_body) {
        std::cerr << "(";
        std::cerr << op_to_string(f_op) << "(";
        for(const auto& tm: bodies) {
            tm->print();
            std::cerr << ",";
        }
        std::cerr << "))";
        return;
    }
	std::cerr << "(";
	std::cerr << op_to_string(f_op) << ",";
	func_range_l->print(); std::cerr << ",";
	func_range_r->print(); std::cerr << ",";
	reduce_body->print(); std::cerr <<")";
}


std::pair<int, int> constval::get_max_ord(const env *e) const {
	if(value < INF)
		return {-INF, INF};
    int ord = e->ord_lookup(value - INF);
	return {ord, ord};
}

std::pair<int, int> atom_term::get_max_ord(const env* e) const {
	int ans = 0;
    int ans2 = 10000000;
    int st = 0;
    if(f_op >= 6) st = 1;
	for(int i = st; i < oprands.size(); i ++) {
		std::pair<int, int> cur = oprands[i]->get_max_ord(e);
		if(cur.first > ans) ans = cur.first;
        if(cur.second < ans2) ans2 = cur.second;
	}
	return {ans, ans2};
}

std::pair<int, int> reduce_term::get_max_ord(const env *e) const {
    int u = -INF;
    int v = INF;
    for(const auto& tm: bodies) {
        auto res = tm->get_max_ord(e);
        u = std::max(u, res.first);
        v = std::min(v, res.second);
    }
    return {u, v};
}

int constval::evaluate(const env *e) const {
	if(ISVAR(value)) {
		return e->lookup(value - INF);
	} else return value;
}

int atom_term::evaluate(const env *e) const {
	vector<int> tmp;
	for(int i = 0; i < oprands.size(); i ++){
        int res;
        if(f_op >= 6 && i == 0) {
            res = static_cast<constval*>(oprands[i])->get_value();
            res -= INF;
        } else {
            res = oprands[i]->evaluate(e);
        }
		tmp.push_back(res);
	}
	term* res = op_to_semantics(f_op)->evaluate(tmp, e);
	return static_cast<constval*>(res)->get_value();
}

int reduce_term::evaluate(const env *e) const {
    if(!flatten_body) {
        return -INF;
    } else {
        int res = 0;
        for(const auto& tm: bodies) {
            res += tm->evaluate(e);
        }
        return res;
    }
}
