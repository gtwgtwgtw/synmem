//
// Created by gtw on 22-5-5.
//

#ifndef DPSYN_SYNTAX_H
#define DPSYN_SYNTAX_H

#include "core.h"


class term {
public:
	int isconst;
    int isCovered;
	term() {isconst = isCovered = 0;}
    void set_cover(int w) {isCovered = w;}
	explicit term(int w) {isconst = w; isCovered = 0;}
	virtual ~term() = default;
	virtual term* simplify(const env* e)  = 0;
	virtual int contains(int _name) const = 0;
	virtual term* deepcopy() const = 0;
	virtual void print() const = 0;
	virtual std::pair<int, int> get_max_ord(const env* e) const = 0;
    virtual int get_ord_max(const env* e) const {
        return get_max_ord(e).first;
    }
    virtual int get_ord_min(const env* e) const {
        return get_max_ord(e).second;
    }
    virtual pair<int, int> get_ord(const env* e) const {
        return get_max_ord(e);
    }
	virtual int evaluate(const env* e) const = 0;
	int is_const() const { return isconst; }
};

class constval : public term {
	int value;
public:
	~constval() override = default;
	
	explicit constval (int _value) : value(_value), term(1) {}
	constval () { value = 0; isconst = 1; }
	constval (const constval &a): term(1) { value = a.value; }
	int get_value() const { return value; }
	
	term* simplify(const env* e) override;
	term* deepcopy() const override;
	int contains(int name) const override;
	void print() const override;
    std::pair<int, int> get_max_ord(const env* e) const override;
	int evaluate(const env* e) const override;
//	int is_const() const override { return value < INF; }
};



class atom_term : public term {
	int f_op;
	vector<term*> oprands;
public:
	term* get_oprand(int i) const {
		if(i < 0 || i >= oprands.size())
			return nullptr;
		return oprands[i];
	}
	int get_operator() const {
		return f_op;
	}
	atom_term() {
		f_op = 0;
		oprands.resize(2);
		isconst = 0;
	}
	~atom_term() override {
		for(const auto &u: oprands)
			delete u;
		oprands.clear();
		f_op = 0;
	}
	atom_term(int _f_op, vector<term*> _oprands) {
		f_op = _f_op;
		oprands.clear();
		isconst = 0;
		for(const auto &u: _oprands) {
			oprands.push_back(u);
		}
	}
	
	atom_term(const atom_term &a): term(0), f_op(a.f_op), oprands(a.oprands) { isconst = 0; }
	
	int evaluate(const env* e) const override;
	term* simplify(const env* e) override;
	term* deepcopy() const override;
	int contains(int _name) const override;
    std::pair<int, int> get_max_ord(const env* e) const override;
	void print() const override;
};

class reduce_term : public term {
	int f_op;
	term* func_range_l;
	term* func_range_r;
	int range_var;
	term* reduce_body;
    vector<term*> bodies;
    bool flatten_body;
    bool enum_way;
public:
	term* get_body() const {
		return reduce_body->deepcopy();
	}
	
	int get_range_var() const {
		return range_var;
	}
	
	int get_operator() const {
		return f_op;
	}
	reduce_term(): term(0) {
		f_op = 0;
		func_range_l = func_range_r = nullptr;
		range_var = 0;
		reduce_body = nullptr;
        bodies.clear();
        flatten_body = false;
	}
	~reduce_term() override {
		f_op = 0;
		range_var  = 0;
		delete func_range_l;
		delete func_range_r;
		delete reduce_body;
        for(const auto& tm: bodies)
            delete tm;
        bodies.clear();
	}
	
	reduce_term(const reduce_term &a):
		term(0),
		f_op(a.f_op),func_range_l(a.func_range_l),
		func_range_r(a.func_range_r), range_var(a.range_var),
		reduce_body(a.reduce_body),
        bodies(),
        flatten_body(false), enum_way(false) {}
	
	reduce_term(int _f_op, term* _func_range_l, term* _func_range_r,
				int _range_var, term* _reduce_body) {
		f_op = _f_op;
		func_range_l = _func_range_l;
		func_range_r = _func_range_r;
		range_var = _range_var;
		reduce_body = _reduce_body;
        bodies.clear();
        flatten_body = false;
        enum_way = false;
	}
	
	int evaluate(const env* e) const override;
	term* deepcopy() const override;
	int contains(int _name) const override;
	term* simplify(const env* e) override;
	vector<term*> transform(env* e) const;
    std::pair<int, int> get_max_ord(const env* e) const override;
	void print() const override;

    const vector<term*>& get_bodies() const {
        return bodies;
    }

    const term* get_func_range_l() const {
        return func_range_l;
    }

    void set_flatten() {
        flatten_body = true;
    }

    void add_term(term* tm) {
        bodies.push_back(tm->deepcopy());
    }

    void set_enum() {
        enum_way = true;
    }
};

#endif //DPSYN_SYNTAX_H
