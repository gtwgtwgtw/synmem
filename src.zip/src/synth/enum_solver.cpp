//
// Created by gtw on 22-5-17.
//

#include "enum_solver.h"

void recursion(const vector<vector<int> >& ord,
					   const vector<vector<domain> >& doms,
                       scheduler* s,
		search_tree* parent,
        root_path& path,
        example_info& info,
        computation_info& cinfo,
		int step, int idx, env* e, const int mnTimes, const example* ex)
{
	if(step >= ord.size()) {
        const vector<term*>& tmp = s->get_constraint(step);
        int k1 = 1;
        if(!tmp.empty()) {
            for(const auto& constraint: tmp) {
                k1 &= constraint->evaluate(e);
                if(k1 == false)
                    break;
            }
        }
        if(k1 == 0)
            k1 = -INF;
		parent->set_optimal(k1);
		return;
	}
	domain cur_dom = doms[step][idx];
	int cur_var = ord[step][idx];
#if DEBUG
    fprintf(stderr, "step = %d, idx = %d, cur_var = %d, cur_dom = (%d, %d), sz = %d, step_sz = %d\n", step, idx, cur_var, cur_dom.first, cur_dom.second, ord.size(), ord[step].size());
#endif
	bool jump = (idx + 1 == ord[step].size());
	vector<term*> constraint;
	if(jump) {
        const vector<term*>& tmp = s->get_constraint(step);
        if(!tmp.empty()) {
            for(const auto& u: tmp)
                constraint.push_back(u->deepcopy()->simplify(e));
        }
    }

	for(int i = cur_dom.first; i <= cur_dom.second; i ++) {
#if DEBUG
        fprintf(stderr, "(enum, %d, %d)\n", cur_var, i);
#endif
		e->update_value(cur_var, i);
#if DEBUG
        fprintf(stderr, "branch %d %d\n", cur_var, i);
#endif
		if(jump) {
            if(step == mnTimes) {
                s->set_constraints(ex, e);
            }

            bool k1 = true;
            reduce_term* w = s->contains_reduced(step);
            for(const auto& tm: constraint) {
                k1 &= tm->evaluate(e);
                if(!k1)
                    break;
            }


			if(k1) {
                auto* new_root = new search_tree();
                for(int j = 0; j <= idx; j ++)
                    new_root->set_value(j, ord[step][j], e->lookup(ord[step][j]));
                parent->add_branch(new_root);
                path.add_node(new_root);
                if(w != nullptr) {
                    const vector<term*>& bodies = w->get_bodies();
//                    int l = w->get_func_range_l()->evaluate(e);
                    static vector<int> tmp_value;
                    tmp_value.clear();
                    for(const auto& tm: bodies)
                        tmp_value.push_back(tm->evaluate(e));
                    int is_add_op = w->get_operator() == string_to_op("Add");
                    int k_value = (is_add_op) ? 0 : 1;
                    for(int ix = 0; ix < bodies.size(); ix ++) {
                        if(is_add_op) {
                            k_value += tmp_value[ix];
                        } else {
                            k_value &= tmp_value[ix];
                        }
                        cinfo.emplace_back(path, ix, k_value, 1);
#if DEBUG4
                        fprintf(stderr, "[NEW CINFO]");
                        cinfo.back().print();
                        fprintf(stderr, "\n");
#endif
                    }
                    k_value = (is_add_op) ? 0 : 1;
                    for(int ix = bodies.size() - 1; ix >= 0; ix --) {
                        if(is_add_op) {
                            k_value += tmp_value[ix];
                        } else {
                            k_value &= tmp_value[ix];
                        }
                        cinfo.emplace_back(path, bodies.size() - ix - 1, k_value, 0);
#if DEBUG4
                        fprintf(stderr, "[NEW CINFO]");
                        cinfo.back().print();
                        fprintf(stderr, "\n");
#endif
                    }
/*
                    for(int ix = 0, jx = bodies.size() - 1; ix <= jx; ix ++, jx --) {
                        if(is_add_op) {
                            k_value += tmp_value[ix];
                            if(ix < jx) k_value += tmp_value[jx];
                        } else {
                            k_value &= tmp_value[ix];
                            if(ix < jx) k_value &= tmp_value[jx];
                        }
                        cinfo.emplace_back(path, ix, k_value, 2);
                    }
*/
                }
				recursion(ord, doms, s, new_root, path, info, cinfo, step + 1, 0, e, mnTimes, ex);
                int optimal = new_root->get_optimial();
				if(optimal == 1)
					parent->set_optimal(1);
                path.set_optimal(new_root->get_optimial());
                info.emplace_back(path);
                path.del_back();
			}
		} else {
            recursion(ord, doms, s, parent, path, info, cinfo, step, idx + 1, e, mnTimes, ex);
		}
	}


    if(!constraint.empty()) {
        for(const auto& u: constraint)
            delete u;
        constraint.clear();
    }
	e->update_value(cur_var, -INF);
}

void get_tree(scheduler *s, example *ex, example_info& info, computation_info& cinfo, search_tree* root, int mnTimes) {
    root_path k_path;
    auto ww = new env(*ex->get_env());
    recursion(s->get_ord(), s->get_doms(), s, root, k_path, info, cinfo, 0, 0, ww, mnTimes, ex);
    delete ww;
}

search_tree* base_solver::get_search_tree_from_scheduler_and_example
        (scheduler *s, example *ex, example_info& info, computation_info& cinfo,
         int mnTimes) {
	auto *root = new search_tree();
	get_tree(s, ex, info, cinfo, root, mnTimes);
    return root;
}

std::pair<scheduler*, example*> base_solver::generate_trace(example_info& info, computation_info& cinfo) {
    example* concrete_problem = meta_problem->generate();
    _s = new scheduler();
    _s->get_scheduler_from_enumerator(_e, concrete_problem);
    if(_s->minTimes == -INF)
        _s->set_constraints(concrete_problem, concrete_problem->get_env());
    search_tree* t = get_search_tree_from_scheduler_and_example(_s, concrete_problem, info, cinfo, _s->minTimes);
    return std::make_pair(_s, concrete_problem);
}
