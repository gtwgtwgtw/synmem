//
// Created by gtw on 22-5-17.
//

#ifndef DPSYN_ENUM_SOLVER_H
#define DPSYN_ENUM_SOLVER_H

#include "example.h"
#include "enumerator.h"
#include "scheduler.h"

class root_path {
    vector<vector<pair<int, int> > > path;
    int optimal;
public:
    root_path() {
        path.clear();
        optimal = -INF;
    }
    void add_node(search_tree *w) {
        const vector<int>& id = w->get_varid();
        const vector<int>& val = w->get_value();
        vector<pair<int, int> > tmp; tmp.resize(id.size());
        int i = 0;
        for(; i < id.size(); i ++) {
            if(!id[i])
                break;
            tmp[i] = std::make_pair(id[i], val[i]);
        }
        tmp.resize(i);
        path.push_back(tmp);
    }
    void set_optimal(int _o) {
        optimal = _o;
    }
    int get_optimal() const {
        return optimal;
    }
    const vector<vector<pair<int, int> > >& get_path() const {
        return path;
    }
    void del_back() {
        path.pop_back();
    }
    ~root_path() {
        path.clear();
        optimal = -INF;
    }

    root_path(const root_path& a) = default;
//    root_path(root_path& a) = default;
//    root_path(root_path&& a) = default;

    int operator <(const root_path& a) const {
        return optimal < a.optimal;
    }

    void print() const {

        for(const auto& w: path) {
            if(w.size() == 1) {
                for (int v = 0; v < 1; v++) {
                    fprintf(stderr, "(var%d, %d)", w[v].first, w[v].second);
                }
            } else {
                for (int v = 0; v < 1; v++) {
                    fprintf(stderr, "{(var%d, %d), (var%d, %d)}", w[0].first, w[0].second, w[1].first, w[1].second);
                }
            }
        }

        fprintf(stderr, "\n%d\n", optimal);
    }
};

class computation_path {
    root_path path;
    int i_val;
    int optimal;
    int enm;
public:
    computation_path(): path(), i_val(0), optimal(0), enm(1) {
    }
    explicit computation_path(root_path& _path): path(_path), enm(1) {
        i_val = 0;
        optimal = 0;
    }
    computation_path(root_path& _path, int _i, int _o, int _e):
        path(_path), i_val(_i), optimal(_o), enm(_e) {};
    int get_enm() const {
        return enm;
    }
    int get_optimal() const {
        return optimal;
    }
    int get_i() const {
        return i_val;
    }
    const vector<vector<pair<int, int> > >& get_cpath() const {
        return path.get_path();
    }
    void print() {
        path.print();
        fprintf(stderr, " %d %d %d\n", i_val, optimal, enm);
    }
};

typedef vector<root_path> example_info;
typedef vector<computation_path> computation_info;

class base_solver {
	enumerator* _e;
	example* meta_problem;
    scheduler* _s;
public:
	base_solver() {
		_e = nullptr;
		meta_problem = nullptr;
	}
	explicit base_solver(example* _meta) {
		_e = nullptr;
		meta_problem = _meta;
	}

	std::pair<scheduler*, example*> generate_trace(example_info& info, computation_info& cinfo);
	
	void update_enum(enumerator *__e) {
		_e = __e;
	}

    search_tree *get_search_tree_from_scheduler_and_example(scheduler *s, example *ex, example_info &info, computation_info& cinfo, int mnTimes);
};

enum dsl_type {
    NULLTY,
    INT,
    LIST,
    LIST_LIST,
};
class witness_dsl {
    dsl_type ty;
public:
    explicit witness_dsl(dsl_type _type): ty(_type) {}
    witness_dsl() = default;
    witness_dsl(witness_dsl& a) = default;
    witness_dsl(witness_dsl&& a) = default;
    witness_dsl(const witness_dsl& a) = default;
    dsl_type get_ty() const {
        return ty;
    }
};

#include <unordered_map>

class witness_env {
    vector<witness_dsl*> myenv;
public:
    witness_env() {
        myenv.resize(5);
    }
    void set(int u, witness_dsl* v) {
        myenv[u] = v;
    }
    witness_dsl* get(int u) const {
        return myenv[u];
    }
};

#endif //DPSYN_ENUM_SOLVER_H
