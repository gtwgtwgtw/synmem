//
// Created by 孙奕can on 2022/6/14.
//

#ifndef DPSYN_SCHEDULER_H
#define DPSYN_SCHEDULER_H

#include "enumerator.h"
#include "example.h"

class scheduler {
    vector<vector<int> > ord;
    vector<int> number_env;
    vector<vector<term*> > ord_constraint;
    vector<reduce_term*> contains_reduced_term;
    vector<vector<domain> > doms;
public:
    int minTimes;
    scheduler() {
        ord.clear();
        doms.clear();
        number_env.clear();
        ord_constraint.resize(IDEN_MAX);
        contains_reduced_term.resize(IDEN_MAX);
        minTimes = -INF;
    }

    const vector<vector<int> >& get_ord() const {
        return ord;
    }

    const vector<vector<domain> >& get_doms() const {
        return doms;
    }

    const vector<vector<term*> >& get_constraint() const {
        return ord_constraint;
    }

    const vector<term*>& get_constraint(int i) const {
        return ord_constraint[i];
    }

    const term* get_constraint(int i, int j) const {
        return ord_constraint[i][j];
    }

    reduce_term* contains_reduced(int step) const {
        return contains_reduced_term[step];
    }

    ~scheduler() {
        ord.clear();
        doms.clear();
        for(auto u: ord_constraint) {
            for (auto v: u)
                delete v;
            u.clear();
        }
        ord_constraint.clear();
    }

    const vector<int>& get_number_env() const {
        return number_env;
    }
    scheduler(scheduler&& a) = default;
    scheduler(const scheduler& a) = default;
    void get_scheduler_from_enumerator(enumerator* _e, example* ex);
    void set_constraints(const example* ex, const env* example_env);
};

class search_tree {
    vector<int> varid, value;
    int optimal;
    std::vector<search_tree*> branches;
public:
    int get_optimial() { return optimal; }
    const vector<search_tree*>& get_branches() { return branches; }
    const vector<int>& get_varid() { return varid; }
    const vector<int>& get_value() { return value; }

    search_tree() {
        varid.resize(2);
        value.resize(2);
        optimal = -INF;
        branches.clear();
    }
    ~search_tree() {
        varid.clear();
        value.clear();
        for(const auto&u: branches)
            delete u;
        branches.clear();
    }


    search_tree(vector<int>& _varid, vector<int>& _value, int _optimal,
                term* _m_constraint, std::vector<search_tree*>& _branches):
            varid(std::move(_varid)), value(std::move(_value)), optimal(_optimal),
            branches(std::move(_branches)) {}

    search_tree(search_tree&& a) = default;
    search_tree(const search_tree& a) = default;
    void set_value(int idx, int name, int _value) {
        varid[idx] = name;
        value[idx] = _value;
    }
    void add_branch(search_tree *t) {
        branches.emplace_back(t);
    }
    void set_optimal(int value) {
        optimal = value;
    }

    void print_itself() const {
        for(int i = 0; i < 1; i ++ ) {
            fprintf(stderr, "assign var%d as %d; ", varid[i], value[i]);
        }
        fprintf(stderr, "optimal is %d", optimal);
        fprintf(stderr, "\n");
    }

    void print(int k = 0) const {
        for(int u = 0; u < k * 4; u ++) fprintf(stderr, " ");
        print_itself();
        for(const auto& u: branches) {
            u->print(k + 1);
        }
    }
};


#endif //DPSYN_SCHEDULER_H
