//
// Created by gtw on 22-5-10.
//

#include "enumerator.h"
#include "scheduler.h"

void add_constraints(term* constraint, vector<term*>& ord_constraint, const env* _env, reduce_term*& contains_reduced_term, bool add = true) {
    if(constraint->is_const())
        return;
#if DEBUG
    fprintf(stderr, "[add_constraint] ");
    constraint->print();
    fprintf(stderr, "\n");
#endif
    auto reduced_constraint = dynamic_cast<reduce_term*>(constraint);
    if(reduced_constraint) {
#if DEBUG
        fprintf(stderr, "[make reduced constraint] ");
        reduced_constraint->print();
        fprintf(stderr, "\n");
#endif
        contains_reduced_term = reduced_constraint;
        for(const auto& tm: reduced_constraint->get_bodies()) {
            add_constraints(tm, ord_constraint, _env, contains_reduced_term);
        }
    } else {
        auto atom_constraint = static_cast<atom_term*>(constraint);
        int nwadd = (atom_constraint->get_operator() == string_to_op("And")) && add;
        add_constraints(atom_constraint->get_oprand(0), ord_constraint, _env, contains_reduced_term, nwadd);
        add_constraints(atom_constraint->get_oprand(1), ord_constraint, _env, contains_reduced_term, nwadd);
        if(add) {
#if DEBUG
            fprintf(stderr, "[new_constraint] ");
            atom_constraint->print();
            fprintf(stderr, "\n");
#endif
            ord_constraint.push_back(atom_constraint->deepcopy());
        }
    }
}

void scheduler::set_constraints(const example* ex, const env* example_env) {
    for(int i = 0; i < IDEN_MAX; i ++) {
        if(!ord_constraint[i].empty()) {
            for(const auto& x: ord_constraint[i])
                delete x;
            ord_constraint[i].clear();
        }
        contains_reduced_term[i] = nullptr;
    }

    for(const auto& u: ex->get_constraints()) {
        term* nwtm = u->deepcopy()->simplify(example_env);
        int mx = nwtm->get_ord_max(example_env);
        if(mx >= ord.size())
            mx = ord.size() - 1;
        if(mx < minTimes)
            mx = minTimes;
#if DEBUG
        fprintf(stderr, "[max] = %d\n", mx);
#endif
        add_constraints(nwtm, ord_constraint[mx], example_env, contains_reduced_term[mx]);
    }
}

void scheduler::get_scheduler_from_enumerator(enumerator *_e, example *ex) {
	std::vector<int> l(IDEN_MAX, 0), r(IDEN_MAX, 0);
	const env* example_env = ex->get_env();
	for(int i = 0; i < IDEN_MAX; i ++)
		if(ex->get_label(i) == VAR_LIST) {
			l[i] = 0;
			r[i] = ex->get_length(i);
		}
	int times = -1, timeQ = -1;
    while(_e) {
        ++timeQ;
		const auto& cur_enum = _e->get_var();
		bool enum_list = false;
		for(const auto& u: cur_enum) {
			labels u_label = ex->get_label(u.second);
			if(u_label == VAR_LIST)
				enum_list = true;
#if DEBUG
			fprintf(stderr, "[enum_list] = %d\n", enum_list);
#endif
		}
		vector<int> cur;
		vector<domain> cur_dom;
		if(! enum_list) {
			++times;
            minTimes = times;
			for (const auto &u: cur_enum) {
				labels u_label = ex->get_label(u.second);
#if DEBUG
                fprintf(stderr, "[enum var] %d %d %d (%d, %d)\n", u.second, times, minTimes, example_env->domain_lookup(u.second).first, example_env->domain_lookup(u.second).second);
#endif
				ex->update_ord(u.second, times);
				cur.push_back(u.second);
				cur_dom.push_back(example_env->domain_lookup(u.second));
 			}
            ord.push_back(cur);
            doms.push_back(cur_dom);
            number_env.push_back(timeQ);
		} else {
			while(true) {
				++times;
				bool terminate = true;
				for(const auto& u: cur_enum) {
					if(l[u.second] < r[u.second]) {
						terminate = false;
						break;
					}
				}
				if(terminate) break;
				int var_name = 0;
                cur.clear();
                cur_dom.clear();
				for(const auto&u: cur_enum) {
					switch(u.first) {
						case HEAD:
							var_name = ex->env_list_lookup(u.second, l[u.second], 1);
							l[u.second] ++;
							break;
						case TAIL:
							var_name = ex->env_list_lookup(u.second, r[u.second], 1);
							r[u.second] --;
							break;
					}
#if DEBUG
					fprintf(stderr, "state %d %d %d\n", u.second, l[u.second], r[u.second]);
					fprintf(stderr, "enum %d %d\n", var_name - INF, times);
#endif
					ex->update_ord(var_name - INF, times);
                    cur.push_back(var_name - INF);
                    cur_dom.push_back(example_env->domain_lookup(var_name - INF));
				}
                ord.push_back(cur);
                doms.push_back(cur_dom);
                number_env.push_back(timeQ);
			}
		}
		_e = _e->get_next();
	}

#if DEBUG
	for(int i = 0; i < ord.size(); i ++) {
		fprintf(stderr, "var ");
		for(const auto&u: ord[i]) fprintf(stderr, "%d ", u);
		fprintf(stderr, "\n");
		fprintf(stderr, "dom ");
		for(const auto&u: doms[i]) fprintf(stderr, "(%d,%d)", u.first, u.second);
		fprintf(stderr, "\n");
	}
#endif

}