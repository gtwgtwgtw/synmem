//
// Created by gtw on 22-5-5.
//

#ifndef DPSYN_SEMANTICS_H
#define DPSYN_SEMANTICS_H

#include "core.h"
#include "env.h"
#include <string>
using std::string;

class semantics {
public:
	virtual term* evaluate(const vector<int>& u, const env* e) const = 0;
};

class Add;
class Mult;
class Sub;
class And;
class Less;
class Greater;
class Equal;
class Call;

class Add: public semantics {
public:
	term* evaluate(const vector<int>& u, const env* e) const override {
#if DEBUG
		assert(u.size() == 2);
#endif
		return new constval(u[0] + u[1]);
	}
};

class opOr: public semantics {
public:
    term* evaluate(const vector<int>& u, const env* e) const override {
#if DEBUG
        assert(u.size() == 2);
#endif
        return new constval(u[0] || u[1]);
    }
};

class Mult: public semantics {
public:
    term* evaluate(const vector<int>& u, const env* e) const override {
        return new constval(u[0] * u[1]);
    }
};

class Div: public semantics {
public:
    term* evaluate(const vector<int>& u, const env* e) const override {
        return new constval(u[0] / u[1]);
    }
};

class Sub: public semantics {
public:
	term* evaluate(const vector<int>& u, const env* e) const override {
#if DEBUG
		assert(u.size() == 2);
#endif
		return new constval(u[0] - u[1]);
	}
};

class And: public semantics {
public:
	term* evaluate(const vector<int>& u, const env* e) const override {
#if DEBUG
		assert(u.size() == 2);
#endif
		return new constval(u[0] & u[1]);
	}
};

class Less: public semantics {
public:
	term* evaluate(const vector<int>& u, const env* e) const override {
#if DEBUG
		assert(u.size() == 2);
#endif
		return new constval(u[0] < u[1]);
	}
};

class Greater: public semantics {
public:
	term* evaluate(const vector<int>& u, const env* e) const override {
#if DEBUG
		assert(u.size() == 2);
#endif
		return new constval(u[0] > u[1]);
	}
};

class Equal: public semantics {
public:
	term* evaluate(const vector<int> &u, const env* e) const override {
#if DEBUG
		assert(u.size() == 2);
#endif
		return new constval(u[0] == u[1]);
	}
};


class Call: public semantics {
	int calltype;
public:
	Call(): calltype(0) {}
	explicit Call(int _): calltype(_) {}
	Call(const Call& a): calltype(a.calltype) {}
	
	void settype(int _) {
		calltype = _;
	}

	term* evaluate(const vector<int>& u, const env* e) const override {
#ifdef DEBUG
		assert(u.size() == 2);
#endif
		int res = e->list_lookup(u[0], u[1], calltype);
		return new constval(res);
	}
};

int string_to_op(const string &u);
string op_to_string(int u);


#endif //DPSYN_SEMANTICS_H
