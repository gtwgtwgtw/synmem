//
// Created by gtw on 22-4-27.
//

#ifndef DPSYN_CORE_H
#define DPSYN_CORE_H
#include "../util/util.h"
#include <algorithm>
#include <vector>
#include <map>
#include <set>

using std::pair;
using std::make_pair;
using std::vector;
using std::map;
using std::set;

typedef pair<int,int> bounded_int;
class term;
class semantics;
class env;


#endif //DPSYN_CORE_H
