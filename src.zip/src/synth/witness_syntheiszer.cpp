//
// Created by 孙奕can on 2022/5/19.
//

#include "witness_syntheiszer.h"
#include <unordered_map>

typedef pair<witness_env*, witness_env*> ctexample_type_env;
typedef vector<ctexample_type_env> info_type;

string constructor_name[15];
std::map<string, int> constructor_to_id;
int list_map_op;
int sum_op;
int start_pos;
int KSizeMax;
int plist_id;
bool aug_pool;
witness synthesisCandidate[20];
vector<lin_exp_program> lin_exp_pool[20];
vector<lin_exp> lin_exp_var_pool;
vector<constructors*> registeredConstructor;
vector<NonTerminalType> typeOfConstructor;
vector<dsl_type> inputType;
vector<dsl_type> outputType;
int end_pos_lin_exp_var_pool;
info_type ginfos[2];
vector<int> covered[2];
long double tim = 0;

void synthesis_clear() {
    for(auto & i : constructor_name) i = "";
    constructor_to_id.clear();
    list_map_op = 0;
    KSizeMax = 0;
    sum_op = 0;
    start_pos = 0;
    plist_id = 0;
    aug_pool = false;
    for(int i = 0; i < 20; i ++) {
        synthesisCandidate[i].clear();
        lin_exp_pool[i].clear();
    }
    lin_exp_var_pool.clear();
    registeredConstructor.clear();
    typeOfConstructor.clear();
    inputType.clear();
    outputType.clear();
    end_pos_lin_exp_var_pool = 0;
    ginfos[0].clear();
    ginfos[1].clear();
    covered[0].clear();
    covered[1].clear();
    tim = 0;
}

#define gettype(var) (((var) == plist_id) ? (LIST_LIST) : INT)

void mk_lin_exp(term* val, lin_exp_coef& u, vector<term*>& rest, int cf, int label, const env* e) {
#if DEBUG6
    fprintf(stderr, "[mk_lin_exp, current_term] = %d, %d ", cf, label);
    val->print();
    fprintf(stderr, "\n");
#endif
    if(val->is_const()) {
        auto min_max_ord = val->get_ord(e);
        if(min_max_ord.first !=-INF && min_max_ord.first < label) {
#if DEBUG6
            fprintf(stderr, "[add_lin_exp] ord = %d, current = ", min_max_ord.first); val->print();
            fprintf(stderr, ", coef = %d\n", cf);
#endif
            u.add(val, cf);
        }
        return;
    } else {
        auto* tm = dynamic_cast<atom_term*>(val);
        if(!tm) {
            auto* rterm = static_cast<reduce_term*>(val);
            for(auto tm: rterm->get_bodies())
                mk_lin_exp(tm, u, rest, 1, label, e);
            return;
        }

        int op = tm->get_operator();
        if(op == -1) {
            int value = tm->get_oprand(0)->evaluate(e);
            mk_lin_exp(tm->get_oprand(1), u, rest, cf * value, label, e);
            return;
        }
        if(op == 0) {
            mk_lin_exp(tm->get_oprand(0), u, rest, cf, label, e);
            mk_lin_exp(tm->get_oprand(1), u, rest, cf, label, e);
            return;
        }
        if(op == 1) {
            mk_lin_exp(tm->get_oprand(0), u, rest, cf, label, e);
            mk_lin_exp(tm->get_oprand(1), u, rest, -cf, label, e);
            return;
        }
        if(op >= 6) {
            auto min_max_ord = val->get_ord(e);
            if(min_max_ord.second >= label)
                return;
            if(min_max_ord.first < label)
                u.add(val, cf);
            else {
                rest.emplace_back(val);
            }
        }
        return;
    }

}

void rewrite(term* u, const env* e, int label, vector<pair<term*, lin_exp_coef*> >& result, term* outmost_constraint) {
#if DEBUG6
    fprintf(stderr, "current = ");
    u->print();
    fprintf(stderr, "\n");
#endif
    if(u->is_const()) {
        int ord = static_cast<constval*>(u)->get_ord_max(e);
        if(ord != -INF && ord < label) {
            lin_exp_coef* _u = new lin_exp_coef;
            _u->add(u, 1);
#if DEBUG6
            fprintf(stderr, "ord = %d, add = ", ord);
            _u->print();
            fprintf(stderr, "\n");
#endif
            result.emplace_back(outmost_constraint, _u);
        }
    }

    auto* g = dynamic_cast<atom_term*>(u);
    if(!g) {
        auto* rterm = static_cast<reduce_term*>(u);
        const int and_op = string_to_op("And");
        bool cur = rterm->get_operator() == and_op;
        for(auto tm: rterm->get_bodies())
            rewrite(tm, e, label, result, cur ? tm : outmost_constraint);
        return;
    }

    const int operator_id = g->get_operator();
    //fprintf(stderr, "%d\n", operator_id);
    if(operator_id == 3 || operator_id == -3) {
        rewrite(g->get_oprand(0), e, label, result, g->get_oprand(0));
        rewrite(g->get_oprand(1), e, label, result, g->get_oprand(1));
    }
    if(operator_id == 2 || operator_id == 4 || operator_id == 5) {
        lin_exp_coef* x = new lin_exp_coef;
        vector<term*> rest;
        int cf = (operator_id == 4) ? (-1) : 1;
        mk_lin_exp(g->get_oprand(0), *x, rest, cf, label, e);
        mk_lin_exp(g->get_oprand(1), *x, rest, -cf, label, e);
//        x->print();
        result.emplace_back(outmost_constraint, x);
        for(const auto& next_term: rest)
            rewrite(next_term, e, label, result, outmost_constraint);
    }
}


atomic_term* mk_program_from_var(int id) {
    auto ns = new atomic_term;
    ns->set_var_type(id);
    return ns;
}

atomic_term* mk_program_from_constant(int value) {
    auto ns = new atomic_term;
    ns->set_const_value(value);
    return ns;
}

dsl_type get_output_type(atomic_term* tm) {
    if(tm->get_type() == VAR)
        return gettype(tm->get_var());
    if(tm->get_type() == CONST_VALUE)
        return INT;
    return outputType[tm->get_op()];
}

int gcd(int x, int y) {
    if(!y || !x)
        return x + y;
    return gcd(y, x%y);
}

void dfs_coef(int k1, vector<int> x) {
    if(k1 == -1) {
        int p = 0;
        for(int i: x) p = gcd(p, i);
        if(p == 1)
            lin_exp_var_pool.emplace_back(x, 0, false, false);
        return;
    }
    for(int i = -CoefRange; i <= CoefRange; i ++) {
        x.push_back(i);
        dfs_coef(k1 - 1, x);
        x.pop_back();
    }
}

void lin_exp_aug(int u) {
    if(!aug_pool) {
        aug_pool = true;
        dfs_coef(4, {});
    }

    for(int x = 1; x < u; x ++) {
        int y = u - x;
        for(const auto& program1: synthesisCandidate[x]) {
            if(get_output_type(program1) != INT)
                continue;
            if(!program1->get_all_parameter())
                continue;
            if(program1->get_type() == CONST_VALUE && program1->get_value() == 0)
                continue;
            for (const auto &program2: synthesisCandidate[y]) {
                if(get_output_type(program2) != INT)
                    continue;
                if(program2->get_type() == CONST_VALUE && program2->get_value() == 0)
                    continue;
                lin_exp_pool[u].emplace_back(program1, program2, 0);
                lin_exp_pool[u].emplace_back(program1, program2, 1);
                lin_exp_pool[u].emplace_back(program1, program2, 2);
            }
        }
    }
}


void aug(int u, example* ex) {
    /*
    if(u == 1)
        lin_exp_aug(0);
    lin_exp_aug(u);
    */
#if DEBUG4
    fprintf(stderr, "[cur add size] = %d\n", u);
#endif
    if(u == 0)
        return;
    if(u <= 3)
        lin_exp_aug(u);
    if(u == 1) {
        /*
        for(const auto& id: ex->get_var_list())
            synthesisCandidate[u].push_back(mk_program_from_var(id));
        for(const auto& id: ex->get_var_value())
            synthesisCandidate[u].push_back(mk_program_from_var(id));
            */
        for(int uid = 0; uid <= 4; uid ++) if(uid != 1 && uid != 2)
                synthesisCandidate[u].push_back(mk_program_from_var(uid));
        for(int uid = -KConstantRange; uid <= +KConstantRange; uid ++) {
            synthesisCandidate[u].push_back(mk_program_from_constant(uid));
        }
        return;
    } else {
        for(const auto&program: synthesisCandidate[u - 1]) {
            dsl_type outmost_op_type = get_output_type(program);
#if DEBUG4
            fprintf(stderr, "sz = %d\n", registeredConstructor.size());
#endif
            for(int fst = 0; fst < registeredConstructor.size(); fst ++) {
#if DEBUG4
                fprintf(stderr, "[add op] %d\n", fst);
#endif
                if(inputType[fst] != outmost_op_type || typeOfConstructor[fst] == HIGHER_ORDER || typeOfConstructor[fst] == BINOP)
                    continue;
                auto* cur = new atomic_term(typeOfConstructor[fst], program, fst);
                cur->update_all_parameter(registeredConstructor[fst]->all_parameter());
                synthesisCandidate[u].push_back(cur);
            }
        }
        //TODO: add higher order terms

        for(int fst = 0; fst < registeredConstructor.size(); fst ++) {
            if(typeOfConstructor[fst] != HIGHER_ORDER)
                continue;

            for (int x = 1; x < u - 1; x++) {
                for(const auto& program: synthesisCandidate[x]) {
                    dsl_type output_type = get_output_type(program);
                    if(output_type != inputType[fst])
                        continue;
                    for(const auto& lin_exp: lin_exp_pool[u - 1 - x])
                        if(lin_exp.get_type() == VALUE)
                            synthesisCandidate[u].emplace_back(new atomic_term(fst, program, lin_exp));
                }
            }
        }

        for(int fst = 0; fst < registeredConstructor.size(); fst ++) {
            if(typeOfConstructor[fst] != BINOP)
                continue;

            for (int x = 1; x < u - 1; x++) {
                for(const auto& program: synthesisCandidate[x]) {
                    dsl_type output_type = get_output_type(program);
                    if(output_type != inputType[fst])
                        continue;
                    for(const auto& program2: synthesisCandidate[u - 1 - x]) {
                        if (get_output_type(program2) != inputType[fst])
                            continue;
                        synthesisCandidate[u].emplace_back(new atomic_term(fst, program, program2));
                    }
                }
            }
        }
    }
}


void print(atomic_term* u);
void print_lin_exp(const lin_exp_program* u) {
    print(u->get_coef());
    fprintf(stdout, " * ");
    print(u->get_program());
    if(u->get_type() == EQ0) {
        fprintf(stdout, "==0");
    }
    if(u->get_type() == LE0) {
        fprintf(stdout, "<=0");
    }
    if(u->get_type() == EQ0) {
        fprintf(stdout, "");
    }
}

void print(atomic_term* u) {
    if(u->get_type() == VAR) {
        fprintf(stdout, "var%d", u->get_var());
        return;
    }
    if(u->get_type() == CONST_VALUE) {
        fprintf(stdout, "K%d", u->get_value());
        return;
    }
    if(u->get_type() == LIN_EXP) {
        print_lin_exp(u->getlin());
        return;
    }
    fprintf(stdout, "%s(", constructor_name[u->get_op()].c_str());

    if(typeOfConstructor[u->get_op()] == BINOP) {
        print(u->get_arg());
        fprintf(stdout, " , ");
        print(u->get_arg_curry());
    } else
    if(typeOfConstructor[u->get_op()] == HIGHER_ORDER) {
        print(u->get_arg());
        fprintf(stdout, " , ");
        print_lin_exp(u->getlin());
    } else
        print(u->get_arg());

    fprintf(stdout, ")");
}

witness_dsl* atomic_term::evaluate(witness_env* genv, const env* _env) {
#if DEBUG6
    print(this);
    fprintf(stderr, "\n");
#endif

    if(type == CONST_VALUE) {
        return new witness_atom(value);
    }
    if(type == LIN_EXP) {
        return lin->evaluate(genv);
    }
    if(type == VAR) {
        witness_dsl* cur = genv->get(var);
        if(cur == nullptr)
            return nullptr;

        if(gettype(var) == LIST_LIST)
            return new witness_list_list(*static_cast<witness_list_list*>(cur));
        return new witness_atom(*static_cast<witness_atom*>(cur));
    }

    if(arg == nullptr)
        return nullptr;




    witness_dsl* pvalue = arg->evaluate(genv, _env);
    if(pvalue == nullptr) {
        return nullptr;
    }

#if DEBUG6
    if(pvalue->get_ty() == LIST_LIST) {
        for(const auto& ux: static_cast<witness_list_list*>(pvalue)->get_value()) {
            fprintf(stderr, "{");
            for (const auto &uy: ux)
                fprintf(stderr, "%d,", uy);
            fprintf(stderr, "} ");
        }
        fprintf(stderr, "\n");
    }
#endif


    constructors* cur_op = registeredConstructor[op];
#if DEBUG4
    if(cur_op != nullptr) {
        fprintf(stderr, "[op] = %s\n", constructor_name[op].c_str());
    }
    if(pvalue->get_ty() == LIST_LIST)
        fprintf(stderr, "LISTLIST\n");
#endif

    witness_dsl* result;
    if(typeOfConstructor[op] == HIGHER_ORDER) {
        auto* cur_op_2 = static_cast<list_map_list_list_to_list*>(cur_op);
        cur_op_2->set_term_lin(lin);
        result = cur_op_2->evaluate(genv, pvalue, nullptr, _env);
    } else
    if(typeOfConstructor[op] == BINOP){
        auto* cur_op_2 = static_cast<access_list_list*>(cur_op);
        witness_dsl* qvalue = arg_curry->evaluate(genv, _env);
        if(qvalue == nullptr)
            return nullptr;
        result = cur_op_2->evaluate(genv, pvalue, qvalue, _env);
        delete qvalue;
    } else {
        result = cur_op->evaluate(genv, pvalue, nullptr, _env);
    }


    delete pvalue;
    return result;
}

vector<int> get_value(witness_dsl* cur) {
    if(cur->get_ty() == INT) {
        return {static_cast<witness_atom*>(cur)->get_value() };
    }
    if(cur->get_ty() == LIST) {
        return static_cast<witness_list*>(cur)->get_value();
    }
    return {};
}

void cover(const vector<int>& cur, term* tm, int& nCover, vector<term*>& markedAsCovered) {
#if DEBUG4
    fprintf(stderr, "[current_term] = %d", tm->is_const());
    tm->print();
    fprintf(stderr, "\n");
#endif
    if(tm->is_const() && !tm->isCovered) {
#if DEBUG4
        tm->print();
        fprintf(stderr, "\n");
#endif
        int id = static_cast<constval*>(tm)->get_value() - INF;
        //fprintf(stderr, "id = %d\n", id);
        bool hit = false;
        for(const auto& u: cur) {
            if(u == id) {
                hit = true;
                break;
            }
        }
        if(hit) {
            tm->set_cover(1);
            markedAsCovered.push_back(tm);
            nCover --;
#if DEBUG4
            fprintf(stderr, "\nhit %d\n", nCover);
#endif
        }
        return;
    }
    if(tm->is_const()) {
        return;
    }
    atom_term* atm_tm = static_cast<atom_term*>(tm);
    int st = (atm_tm->get_operator() >= 6) ? 1 : 0;
    int nOperands = 2;
    for(int i = st; i < nOperands; i ++) {
        cover(cur, atm_tm->get_oprand(i), nCover, markedAsCovered);
    }
}

void cover(const vector<int>& cur, closure_type& closure, int& nCover, vector<term*>& markedAsCovered) {
#if DEBUG4
    for(const auto& u: cur) fprintf(stderr, "%d ", u);
    fprintf(stderr, "\n");
#endif
    for(auto& lin_exp_tm: closure) {
        for(auto& tm: lin_exp_tm.second->get_a()) {
            cover(cur, tm, nCover, markedAsCovered);
        }
#if DEBUG4
        fprintf(stderr, "cur = "); lin_exp_tm.second->print();
        fprintf(stderr, "\nrest = %d\n", nCover);
#endif
    }
}


void try_expand_lin(const lin_exp_program* program, witness_env* genv, const env* _e, lin_exp_coef* exp, bool& fail) {
    witness_dsl* coef = program->get_coef()->evaluate(genv, _e);
    if(coef == nullptr || coef->get_ty() != INT) {
        fail = true;
        return;
    }
    int coef_value = static_cast<witness_atom*>(coef)->get_value();
    witness_dsl* val = program->get_program()->evaluate(genv, _e);
    if(val == nullptr || val->get_ty() != INT) {
        fail = true;
        return;
    }
    int val_value = static_cast<witness_atom*>(val)->get_value();
    term* nw = new constval(val_value + INF);
    exp->add(nw , coef_value);
    delete nw;
}

void try_expand(atomic_term* program, witness_env* genv, const env* _e, lin_exp_coef* exp, bool& fail) {
#if DEBUG6
    fprintf(stderr, "[try_expand] ");
    print(program);
    fprintf(stderr, "\n");
#endif
    if(program->get_op() == sum_op) {
        try_expand(program->get_arg(), genv, _e, exp, fail);
        return;
    }
    if(program->get_op() == list_map_op) {
        witness_atom* pp;
        witness_atom* qq;
        witness_dsl* result = program->get_arg()->evaluate(genv, _e);
        if(result == nullptr || result->get_ty() != LIST_LIST) {
            fail = true;
            return;
        }
        const auto& cur_vec = static_cast<witness_list_list*>(result)->get_value();
        pp = new witness_atom;
        qq = new witness_atom;
        genv->set(3, pp);
        genv->set(4, qq);
        for(int i = 0; i < cur_vec.size(); i ++) {
            pp->set(i);
            qq->set(cur_vec[i][0]);
            try_expand_lin(program->getlin(), genv, _e, exp, fail);
            if(fail) {
                genv->set(3, nullptr);
                genv->set(4, nullptr);
                delete pp;
                delete qq;
                delete result;
                return;
            }
        }
        delete pp;
        delete qq;
        delete result;
        return;
    }
    if(outputType[program->get_op()] != LIST) {
        fail = true;
        return;
    }
    witness_dsl* cur = program->evaluate(genv, _e);
    if(cur == nullptr || cur->get_ty() != LIST) {
        fail = true;
        return;
    }
    for(const auto& uvalue: static_cast<witness_list*>(cur)->get_value()) {
        term* nw = new constval(uvalue + INF);
        exp->add(nw, 1);
        delete nw;
    }
}

void coverAll(term* tm, int& nCover, vector<term*>& markAsCovered) {
    if(tm->is_const() && !tm->isCovered) {
        tm->set_cover(1);
        nCover--;
        markAsCovered.push_back(tm);
    }
}

bool equals(term* u, term* v) {
    if(!u->is_const() || !v->is_const())
        return false;
    int uvalue = static_cast<constval*>(u)->get_value();
    int vvalue = static_cast<constval*>(v)->get_value();
    return uvalue == vvalue;
}

bool equals(const lin_exp_coef* e1, const lin_exp_coef* e2) {
    const vector<term*>& t1 = e1->get_a();
    const vector<term*>& t2 = e2->get_a();
    const vector<int>& c1 = e1->get_coef();
    const vector<int>& c2 = e2->get_coef();
    if(t1.size() != t2.size())
        return false;
    for(int i = 0; i < t1.size(); i ++) {
        if(!equals(t1[i], t2[i]))
            return false;
        if(c1[i] != c2[i])
            return false;
    }
    return true;
}

int dfs(int cur_left, synthesis_data_info& infos, witness& result, const env* _env, int dSizeMax, int& nCover) {
    //fprintf(stderr, "INVOKING %d\n", cur_left);
    for(int sz = dSizeMax; sz >= 1; sz --) {
        for(const auto& program: synthesisCandidate[sz]) {
            vector<term*> markedAsConvered = {};
            int kCover = nCover;
            witness_env* env = new witness_env();
            for(auto& info: infos) {
                vector<vector<int> > cur_vec;
                int st = 0;
                witness_list_list *inp = nullptr;
                if(plist_id != -1) {
                    for (int i = start_pos; i < info.first.size(); i++)
                        cur_vec.push_back(info.first[i]);
                    inp = new witness_list_list(cur_vec);

#if DEBUG6
                    fprintf(stderr, "[data] = ");
                    for(const auto& u: inp->get_value()) {
                        for(const auto& v: u) {
                            fprintf(stderr, "%d ", v);
                        }
                    }
                    fprintf(stderr, "\n");
                    fprintf(stderr, "[program] = ");
                    print(program);
                    fprintf(stderr, "\n");
#endif
                    env->set(plist_id, inp);
                    st = 1;
                }
                for(int i = 0; i < start_pos; i ++) {
                    env->set(i + st, new witness_atom(info.first[i][0]));
                }
//                fprintf(stderr, "must get = %d\n", ex->get_env()->list_lookup(1, 0, 3));
                witness_dsl* cur = program->evaluate(env, _env);
#if DEBUG4
#endif


                if(cur == nullptr) {
                    //fprintf(stderr, "nullptr da\n");
                    auto* exp = new lin_exp_coef;
                    bool fail = false;
                    if(program->get_op() == sum_op)
                        try_expand(program, env, _env, exp, fail);
                    else
                        fail = true;
                    if(!fail) {
                        for (auto &lin_exp_tm: info.second) {
                            if(equals(lin_exp_tm.second, exp)) {
                                for(auto& tm: lin_exp_tm.second->get_a())
                                    coverAll(tm, nCover, markedAsConvered);
                            }
                        }
                    }
                    //fprintf(stderr, "nullptr ends %d\n", fail);

                    delete exp;
                } else {
#if DEBUG6
                    fprintf(stderr, "resultt = ");
                    for(auto u: get_value(cur))
                        fprintf(stderr, "%d, ", u);
                    fprintf(stderr, "\n");
#endif
                    clock_t start = clock();
                    cover(get_value(cur), info.second, nCover, markedAsConvered);

                    clock_t end = clock();
                    tim += double (end - start);
                }
                if(inp)
                    delete inp;

            }
            delete env;
            //fprintf(stderr, "[cover_size] = %d, %d, %d\n", nCover, kCover - nCover, markedAsConvered.size());
            if(nCover + markedAsConvered.size() != kCover) {
                for(;;);
            }
            if((kCover - nCover) * cur_left >= kCover) {
                result.push_back(program);
                if(cur_left == 1)
                    return true;
                if(dfs(cur_left - 1, infos, result, _env, dSizeMax, nCover))
                    return true;
                result.pop_back();
            }

            //fprintf(stderr, "[recover size] = %d, %d, %d\n", markedAsConvered.size(), kCover, nCover);

            nCover += (int) markedAsConvered.size();
            for(const auto& tm: markedAsConvered)
                tm->set_cover(0);
        }
    }
    return false;
}

int synthesis(int numbers, synthesis_data_info& infos, witness& result, example* ex, int dSizeMax, int& nCover) {
#if DEBUG4
    fprintf(stderr, "sizemax = %d\n", dSizeMax);
#endif
    for (; KSizeMax <= dSizeMax; KSizeMax++)
        aug(KSizeMax, ex);

#if DEBUG4
    for(int sz = 1; sz <= 6; sz ++)
    for(const auto& u: synthesisCandidate[sz]) {
//        fprintf(stderr, "program begins\n");
        print(u);
        fprintf(stderr, " %d %d\n", u->get_all_parameter(), sz);
    }
#endif

    const env* _env = ex->get_env();
    //fprintf(stderr, "query = %d\n", _env->list_lookup(1, 5, 3));
    return dfs(numbers, infos, result, _env, dSizeMax, nCover);
}


int getCover(const lin_exp_coef* u) {
    return (int) u->get_a().size();
}

int getCover(const closure_type& u) {
    clock_t start = clock();

    int ans = 0;
    for(const auto& lin_exp_tm: u) {
        ans += getCover(lin_exp_tm.second);
    }


    clock_t end = clock();
    tim += double (end - start);
    return ans;
}

void mk_init_solution(synthesis_data_info& infos, witness& result, example* ex) {
    int nCover = 0;
    for(const auto& u: infos)
        nCover += getCover(u.second);

    //fprintf(stderr, "nCover = %d\n", nCover);

    for(int uSizeMax = 10; uSizeMax <= 10; uSizeMax ++)
        for(int numbers = 1; numbers <= 10; numbers ++) {
            //fprintf(stderr, "numbers %d\n", numbers);
            if(synthesis(numbers, infos, result, ex, uSizeMax, nCover))
                return;

        }
}


int registerCons(constructors* c, const string& name, NonTerminalType _type, dsl_type _inputType, dsl_type _outputType) {
    registeredConstructor.push_back(c);
    typeOfConstructor.push_back(_type);
    inputType.push_back(_inputType);
    outputType.push_back(_outputType);
    constructor_to_id[name] = (int) registeredConstructor.size() - 1;
    constructor_name[registeredConstructor.size() - 1] = name;
    return registeredConstructor.size() - 1;
}

void prepare(example* concrete_problem, scheduler* s) {
    constructor_to_id.clear();
    registerCons(new head_list(), "head_list", LIST_FUNC, LIST, INT);
    registerCons(new last_list(), "last_list", LIST_FUNC, LIST, INT);
    registerCons(new init_list(), "init_list", LIST_FUNC, LIST, LIST);
    registerCons(new tail_list(), "tail_list", LIST_FUNC, LIST, LIST);
    sum_op = registerCons(new list_sum(), "sum", LIST_FUNC, LIST, INT);
    registerCons(new last_list_list(), "last_list_list", LIST_FUNC, LIST_LIST, LIST);
    registerCons(new head_list_list(), "head_list_list", LIST_FUNC, LIST_LIST, LIST);
    registerCons(new init_list_list(), "init_list_list", LIST_FUNC, LIST_LIST, LIST_LIST);
    registerCons(new tail_list_list(), "tail_list_list", LIST_FUNC, LIST_LIST, LIST_LIST);
    const vector<int>& genv = s->get_number_env();
    int cur = 0;
    plist_id = -1;
    start_pos = genv.size();
    for(int i = 0, j; i < genv.size(); i = j) {
        for(j = i; j < genv.size() && genv[j] == genv[i]; j++);
        if(j - i != 1) {
            registerCons(new access_list_list(cur), "access_X", BINOP, INT, INT);
            plist_id = cur;
            cur ++;
            start_pos = i;
            break;
        }
    }
    for(int i = 0; i < start_pos; i ++) {
        char curx[15];
        sprintf(curx, "access_var_%d", i + 1);
        registerCons(new access_var(cur), curx, VAR, NULLTY, INT);
        cur++;
    }
    for(const auto& u: concrete_problem->get_param_list()) {
        string cur = "access_" + concrete_problem->get_name(u);
        //fprintf(stderr, "[add op param list] %d %s\n", u, cur.c_str());
        registerCons(new access_list(10 + u), cur, LIST_FUNC, INT, INT);
    }
    list_map_op = registerCons(new list_map_list_list_to_list(), "listmap", HIGHER_ORDER, LIST_LIST, LIST);
}


void prepare_env(witness_env* env, const vector<vector<pair<int, int> > >& path) {
    int st = 0;
    if(plist_id != -1) {
        vector<vector<int> > curx;
        for(int i = start_pos; i < path.size(); i ++) {
            vector<int> cury;
            for(const auto& t: path[i])
                cury.push_back(t.first);
            curx.push_back(cury);
        }
        env->set(plist_id, new witness_list_list(curx));
        st = 1;
    }
    for(int i = 0; i < start_pos; i ++) {
        env->set(i + st, new witness_atom(path[i][0].second));
    }
}


int evaluate_lin(witness_env* env, const lin_exp& lin) {
    const vector<int>& a = lin.get_a();
    int ans = 0;
    for(int i = 0; i < 5; i ++) {
        witness_dsl* cur = env->get(i);
        if(cur != nullptr && cur->get_ty() == INT) {
            ans += a[i] * static_cast<witness_atom*>(cur)->get_value();
        }
    }
    return ans;
}

int timer;
bool comp_cover(int ty, int num, int kCover, vector<int>& result) {

    if(num == 0) {
        return true;
    }
    for(int i = 0; i < end_pos_lin_exp_var_pool; i ++) {
        int covered_tms = 0;
        vector<int> ids;
        for(int j = 0; j < ginfos[ty].size(); j ++) {
            if(covered[ty][j])
                continue;
            int x = evaluate_lin(ginfos[ty][j].first, lin_exp_var_pool[i]);
            int y = evaluate_lin(ginfos[ty][j].second, lin_exp_var_pool[i]);
            //printf("%d %d %d\n", ty, x, y);

            if(x != y) {
                covered[ty][j] = 1;
                covered_tms ++;
                ids.push_back(j);
            }
        }
//        fprintf(stderr, "covered num = %d %d\n", covered_tms, i);
        if(covered_tms * num >= kCover) {
            result.push_back(i);
            if(comp_cover(ty, num - 1, kCover - covered_tms, result)) {
                return true;
            }
            result.pop_back();
        }
        for(auto j: ids) {
            covered[ty][j] = 0;
        }
    }
    return false;
}

void computation_cover(vector<computation_info>& cinfo, vector<int>& result, vector<example*>& problems, int& enm_s) {
    clock_t start = clock();
    bool xi[5];
    memset(xi, false, sizeof xi);
    for(const auto& info_ex: cinfo) {
        vector<witness_env*> envs;
        envs.clear();
        for(const auto& cpath: info_ex) {
            auto ev = new witness_env();
            prepare_env(ev, cpath.get_cpath());
            ev->set(3, new witness_atom(cpath.get_i()));
            envs.push_back(ev);
            for(int i = 0; i < 5; i ++)
                if(ev->get(i) != nullptr && ev->get(i)->get_ty() == INT)
                    xi[i] = true;
        }
        for(int i = 0; i < info_ex.size(); i ++) {
            const int ty = info_ex[i].get_enm();
            const int opt = info_ex[i].get_optimal();
            for (int j = 0; j < info_ex.size(); j++) {
                if(ty == info_ex[j].get_enm() && opt != info_ex[j].get_optimal()) {
                    //if(ty == 0 && info_ex[i].get_i() == info_ex[j].get_i())
                    //printf("%d %d %d\n", info_ex[i].get_i(), info_ex[i].get_optimal(), info_ex[j].get_optimal());
                    ginfos[ty].emplace_back(envs[i], envs[j]);
                    covered[ty].push_back(0);
                }
            }
        }
    }
#if DEBUG6
    for(int i = 0; i < 5; i ++) fprintf(stderr, "%d", xi[i]);
    fprintf(stderr, "\n");
#endif
    lin_exp_aug(0);
    for(auto& exp: lin_exp_var_pool) {
        const vector<int>& aexp = exp.get_a();
        bool w = true;
        for(int j = 0; j < aexp.size(); j ++) {
            if(!xi[j] && aexp[j]) {
                w = false;
                break;
            }
        }
        exp.set_valid(w);
    }
    stable_sort(lin_exp_var_pool.begin(), lin_exp_var_pool.end());
    end_pos_lin_exp_var_pool = lin_exp_var_pool.size();
    for(int i = 0; i < lin_exp_var_pool.size(); i ++) {
        if(!lin_exp_var_pool[i].get_valid()) {
            end_pos_lin_exp_var_pool = i;
            break;
        }
    }
#if DEBUG6
    fprintf(stderr, "good = %d\n", end_pos_lin_exp_var_pool);
    for(int i = 0; i <= 1; i ++) {
        for(const auto& u: ginfos[i]) {
            int uu[15],vv[15];
            for(int j = 0; j < 5; j ++) {
                witness_dsl* cur = u.first->get(j);
                if(cur && cur->get_ty() == INT)
                    fprintf(stderr, "%d ", uu[j] = static_cast<witness_atom*>(cur)->get_value());
            }
            fprintf(stderr, " | ");
            for(int j = 0; j < 5; j ++) {
                witness_dsl* cur = u.second->get(j);
                if(cur && cur->get_ty() == INT)
                    fprintf(stderr, "%d ", vv[j] = static_cast<witness_atom*>(cur)->get_value());
            }
            int x = uu[0] + uu[3];
            int y = uu[0] + uu[1] - uu[3];
            int z = vv[0] + vv[3];
            int w = vv[0] + vv[1] - vv[3];
            fprintf(stderr, "    %d\n", x == z && y == w);
        }
    }

#endif

    for(int num = 1; num <= 10; num ++) {
        for (int enm = 0; enm <= 1; enm++) {
            if (comp_cover(enm, num, ginfos[enm].size(), result)) {
                fprintf(stderr, "num = %d\n", num);

                clock_t end = clock();
                tim += double (end - start);
                enm_s = enm;
                return;
            }
        }
    }
}

void witness_solver::solve(long double& t) {
    synthesis_data_info infos;
    aug_pool = false;
    prepare(meta_problem, schedulers[0]);

    clock_t start, end;
    start = clock();
    tim = 0;

    if(!concrete_problems[0]->get_type()) {
        for (int i = 0; i < schedulers.size(); i++) {
            scheduler *s = schedulers[i];
            example *ex = concrete_problems[i];
            const env *_e = ex->get_env();
            const vector<vector<int> > &ords = s->get_ord();
            int sz = (int) ords.size();
            vector<vector<int> > a;
            a.push_back(ords[0]);
            for (int j = 1; j < sz; j++) {
                vector<pair<term*, lin_exp_coef *> > closure;
                for (int x: {j, sz}) {
                    const vector<term *> &constraints = s->get_constraint(x);
                    for (const auto &tm: constraints) {
                        term *nw = tm->deepcopy();
                        rewrite(nw, _e, j, closure, nullptr);
                        delete nw;
                    }
                }


#if DEBUG4
                if (!closure.empty()) {
                    fprintf(stderr, "rewrite begin %d\n", j);
                    for (const auto &tm: closure)
                        if(tm.second) tm.second->print();
                    fprintf(stderr, "rewrite end\n");
                }
#endif
//                if (closure.size() > KMinClosure) {
//
//                }
                infos.push_back({a, closure});
                closure.clear();
                a.push_back(ords[j]);
            }
        }

#if     DEBUG4
        for (const auto &u: infos) {
            fprintf(stderr, "info begins\n");
            for (const auto &vec: u.first) {
                fprintf(stderr, "{");
                for (int i = 0; i < vec.size(); i++) {
                    fprintf(stderr, "%d", vec[i]);
                    if (i + 1 < vec.size())
                        fprintf(stderr, ", ");
                }
                fprintf(stderr, "}, ");
            }
            for (const auto &vec: u.second) {
                vec.second->print();
                fprintf(stderr, " ");
            }
            fprintf(stderr, "info ends\n");
        }

#endif
    }
    end = clock();
    t += double(end - start);

    if(!concrete_problems[0]->get_type()) {
        mk_init_solution(infos, result, concrete_problems[0]);
        for (const auto &program: result) {
            print(program);
            fprintf(stdout, "\n");
        }
        t += tim;
    } else {
#if DEBUG6
        fprintf(stderr, "[plist] = %d\n[start_pos] = %d\n", plist_id, start_pos);
#endif
        vector<int> cresult;
        int c;
        computation_cover(computes, cresult, concrete_problems, c);
        fprintf(stderr, "enm = %d\n", c);
        for (const auto &program: cresult) {
            //printf("xx = %d\n", lin_exp_var_pool[program].get_a()[3]);
            lin_exp_var_pool[program].print_stdout();
            fprintf(stderr, "\n");
        }
    }
}

int witness_solver::check() const {
    return 1;
}
