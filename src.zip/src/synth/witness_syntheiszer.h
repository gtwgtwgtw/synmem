//
// Created by 孙奕can on 2022/5/19.
//

#ifndef DPSYN_WITNESS_SYNTHEISZER_H
#define DPSYN_WITNESS_SYNTHEISZER_H

#include "enum_solver.h"
#include "env.h"

void synthesis_clear();

class lin_exp {
    vector<int> a;
    int b;
    bool le0, eq0;
    bool valid;
public:
    lin_exp() {
        a.clear(); b = 0;
        le0 = eq0 = false;
        valid = false;
    }
    lin_exp(const lin_exp& a) = default;
//    lin_exp(lin_exp& a) = default;
//    lin_exp(lin_exp&& a) = default;
    lin_exp(vector<int>& _a, int _b, bool _le0, bool _eq0):
    a(std::move(_a)), b(_b), le0(_le0), eq0(_eq0), valid(false) {};

    void set_eq() {
        eq0 = true;
    }

    void set_le() {
        le0 = true;
    }

    void add(int x) {
        a.push_back(x);
    }

    void pop_back() {
        a.pop_back();
    }

    int evaluate(const vector<int>& x) const {
        int ans = b;
        for(int i = 0; i < a.size(); i ++)
            ans += a[i] * x[i];
        if(le0) return ans < 0;
        if(eq0) return ans == 0;
        return ans;
    }

    int get_size() const {
        return (int) a.size();
    }

    const vector<int>& get_a() const {
        return a;
    }

    void set_valid(bool _v) {
        valid = _v;
    }

    int operator <(const lin_exp& ax) const {
        return valid > ax.valid;
    }

    int get_valid() const {
        return valid;
    }

    void print_stdout() const {
        for(int i = 0; i < a.size(); i ++){
            char tt[15];
            if(i < 3)
                sprintf(tt, "var%d", i);
            else
                sprintf(tt, "i");
            if(a[i])
                fprintf(stderr, "(%s, %d) ", tt, a[i]);
        }
        fprintf(stderr, "\n");
        //puts("");
    }
};

class lin_exp_coef {
    vector<int> coef;
    vector<term*> a;
    int b;
    bool le0, eq0;
public:
    lin_exp_coef() {
        a.clear(); b = 0;
        coef.clear();
        le0 = eq0 = false;
    }
    lin_exp_coef(const lin_exp_coef& a) = default;
    lin_exp_coef(lin_exp_coef& a) = default;
    lin_exp_coef(lin_exp_coef&& a) = default;
    lin_exp_coef(vector<term*>& _a, vector<int>& _cf, int _b, bool _le0, bool _eq0):
        a(std::move(_a)), coef(std::move(_cf)), b(_b), le0(_le0), eq0(_eq0) {};
    lin_exp_coef(vector<term*>& _a,
                 vector<int>& _cf,
                 vector<int>& _previous_vars,
                 vector<int>& _back_vars,
                 vector<int>& _violated, int _b, bool _le0, bool _eq0):
            a(std::move(_a)), coef(std::move(_cf)), b(_b), le0(_le0), eq0(_eq0)
            {};
    ~lin_exp_coef() {
        for(const auto&u: a)
            delete u;
        a.clear();
        coef.clear();

    }

    void set_eq() {
        eq0 = true;
    }

    void set_le() {
        le0 = true;
    }

    void add(term* _a, int _b) {
        a.push_back(_a->deepcopy());
        coef.push_back(_b);
    }

    void print() const {
#ifdef DEBUG2
        for(int i = 0; i < coef.size(); i ++ ) {
            fprintf(stderr, "(%d) * ", coef[i]);
            a[i]->print(); fprintf(stderr, " + ");
        }
        fprintf(stderr, " %d\n", b);
#endif
    }

    const vector<term*>& get_a() const {
        return a;
    }

    const vector<int>& get_coef() const {
        return coef;
    }
};




typedef int atom_type;

class witness_atom : public witness_dsl {
    atom_type value;
public:
    witness_atom(): witness_dsl(INT) { value = -INF; }
    explicit witness_atom(atom_type u): value(u), witness_dsl(INT) {}
    witness_atom(const witness_atom& a): witness_dsl(INT) { value = a.value; }
    witness_atom(witness_atom&& a): witness_dsl(INT)  { value = a.value; }
    witness_atom(witness_atom& a): witness_dsl(INT) { value = a.value; }

    atom_type get_value() const {
        return value;
    }

    void set(int _value) {
        value = _value;
    }
};

class witness_list : public witness_dsl {
    vector<atom_type> value;
public:
    witness_list(): witness_dsl(LIST) { value.clear(); }
    explicit witness_list(const vector<atom_type>& a): witness_dsl(LIST), value(a) {}
    explicit witness_list(vector<atom_type>& a): witness_dsl(LIST), value(std::move(a)) {}
    //explicit witness_list(vector<atom_type> a): witness_dsl(LIST), value(a) {}
    witness_list(const witness_list& a): witness_dsl(LIST) { value = a.value; }
    witness_list(witness_list&& a): witness_dsl(LIST)  { value = a.value; }
    witness_list(witness_list& a): witness_dsl(LIST) { value = a.value; }

    const vector<atom_type>& get_value() const {
        return value;
    }
};

class witness_list_list : public witness_dsl {
    vector<vector<atom_type> > value;
public:
    witness_list_list(): witness_dsl(LIST_LIST) { value.clear(); }
    explicit witness_list_list(vector<vector<atom_type> >& a): witness_dsl(LIST_LIST), value(std::move(a)) {}
    explicit witness_list_list(const vector<vector<atom_type> >& a): witness_dsl(LIST_LIST), value(a) {}
    witness_list_list(const witness_list_list& a): witness_dsl(LIST_LIST) { value = a.value; }
    witness_list_list(witness_list_list&& a): witness_dsl(LIST_LIST)  { value = a.value; }
    witness_list_list(witness_list_list& a): witness_dsl(LIST_LIST) { value = a.value; }

    const vector<vector<atom_type> >& get_value() const {
        return value;
    }
};

class atomic_term;

class constructors {
    bool requiresLinExp;
public:
    constructors(): requiresLinExp(false) {}
    explicit constructors(bool w): requiresLinExp(w) {}
    virtual witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const = 0;
    virtual bool all_parameter() const {
        return false;
    }
};

class head_list: public constructors {
public:
    head_list(): constructors(false) {}
    witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input->get_ty() == LIST) {
            const auto& val = static_cast<witness_list *>(input)->get_value();
            if(val.empty())
                return new witness_atom(-INF);
            return new witness_atom(val[0]);
        }
        return nullptr;
    }
};

class tail_list: public constructors {
public:
    tail_list(): constructors(false) {}
    witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input->get_ty() == LIST) {
            const auto& val = static_cast<witness_list *>(input)->get_value();
            vector<int> u;
            if(val.empty())
                return new witness_list(u);
            for(int i = 1; i < val.size(); i ++)
                u.push_back(val[i]);
            return new witness_list(u);
        }
        return nullptr;
    }
};

class init_list: public constructors {
public:
    init_list(): constructors(false) {}
    witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input->get_ty() == LIST) {
            vector<int> val = static_cast<witness_list *>(input)->get_value();
            if(val.empty())
                return new witness_list(val);
            val.pop_back();
            return new witness_list(val);
        }
        return nullptr;
    }
};

class last_list: public constructors {
public:
    last_list(): constructors(false) {}
    witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input->get_ty() == LIST) {
            const auto& val = static_cast<witness_list *>(input)->get_value();
            if(val.empty())
                return new witness_atom(-INF);
            return new witness_atom(val.back());
        }
        return nullptr;
    }
};

class head_list_list: public constructors {
public:
    head_list_list(): constructors(false) {}
    witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input->get_ty() == LIST_LIST) {
            const auto& val = static_cast<witness_list_list*>(input)->get_value();
            vector<int> u;
            if(val.empty())
                return new witness_list(u);
            return new witness_list(val.back());
        }
        return nullptr;
    }
};

class last_list_list: public constructors {
public:
    last_list_list(): constructors(false) {}
    witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input->get_ty() == LIST_LIST) {
            const auto& val = static_cast<witness_list_list*>(input)->get_value();
            vector<int> u;
            if(val.empty())
                return new witness_list(u);
            return new witness_list(val.back());
        }
        return nullptr;
    }
};

class init_list_list: public constructors {
public:
    init_list_list(): constructors(false) {}
    witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input->get_ty() == LIST_LIST) {
            auto u = static_cast<witness_list_list *>(input)->get_value();
            if(u.empty())
                return new witness_list_list(u);
            u.pop_back();
            return new witness_list_list(u);
        }
        return nullptr;
    }
};

class tail_list_list: public constructors {
public:
    tail_list_list(): constructors(false) {}
    witness_dsl* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input->get_ty() == LIST_LIST) {
            const auto& val = static_cast<witness_list_list *>(input)->get_value();
            vector<vector<int> > u;
            if(val.empty())
                return new witness_list_list(u);
            for(int i = 1; i < val.size(); i ++)
                u.push_back(val[i]);
            return new witness_list_list(u);
        }
        return nullptr;
    }
};
//CLIA formula

class access_list: public constructors {
    int which;
public:
    access_list(): constructors(true) { which = 0; }
    access_list(int _id): constructors(true) { which = _id; }
    witness_atom* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        if(input == nullptr)
            return nullptr;
        int position0 = static_cast<witness_atom*>(input)->get_value();
        //fprintf(stderr, "access param = %d, %d, %d\n", which - 10, position0, 3);
        int val = _env->list_lookup(which - 10, position0, 3);
        //fprintf(stderr, "access result = %d\n", val);
        if(val == -INF)
            return nullptr;
        return new witness_atom(val);
    }
    bool all_parameter() const override {
        return which >= 10;
    }
};

class access_var: public constructors {
    int which;
public:
    access_var() : constructors(true) { which = 0; }

    access_var(int _id) : constructors(true) { which = _id; }

    witness_atom *
    evaluate(witness_env *genv, witness_dsl *input, witness_dsl *input_curry, const env *_env) const override {
        return new witness_atom(static_cast<witness_atom *>(genv->get(which))->get_value());
    }
};

class access_list_list: public constructors {
    int which;
public:
    access_list_list(): constructors(true) { which = 0; }
    access_list_list(int _id): constructors(true) { which = _id; }
    witness_atom* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        const vector<vector<int> >& cur = static_cast<witness_list_list*>(genv->get(which))->get_value();
        int position0 = static_cast<witness_atom*>(input)->get_value();
        int position1 = static_cast<witness_atom*>(input_curry)->get_value();
        if(position0 < 0 || position1 < 0 || position0 >= cur.size())
            return nullptr;
        if(position1 >= cur[position0].size())
            return nullptr;
        return new witness_atom(cur[position0][position1]);
    }
};


class lin_exp_program;


enum NonTerminalType {
    HIGHER_ORDER,
    LIST_FUNC,
    LIN_EXP,
    BINOP,
    CONST_VALUE,
    VAR,
    VAR_LIST_LIST,
    VAR_ISLIST,
    NULLTYPE
};
class atomic_term {
    NonTerminalType type;
    int var;
    int value;
    int op;
    atomic_term* arg;
    atomic_term* arg_curry;
    const lin_exp_program* lin;
    bool all_parameters;
public:
    atomic_term(NonTerminalType _type, atomic_term* _arg, int _op):
            type(_type), arg(_arg), arg_curry(nullptr), var(0), op(_op), value(0), all_parameters(false), lin(nullptr) {}

    atomic_term(): type(NULLTYPE) {
        arg = nullptr;
        arg_curry = nullptr;
        var = 0;
        op = 0;
        value = 0;
        lin = nullptr;
        all_parameters = false;
    }

    atomic_term(int _op, atomic_term* _prog, const lin_exp_program& _lin) {
        type = HIGHER_ORDER;
        lin = &_lin;
        arg = _prog;
        arg_curry = nullptr;
        op = _op;
        value = 0;
        var = 0;
        all_parameters = false;
    }

    atomic_term(int _op, atomic_term* _prog, atomic_term* _prog2) {
        type = BINOP;
        lin = nullptr;
        arg = _prog;
        arg_curry = _prog2;
        op = _op;
        value = 0;
        var = 0;
        all_parameters = false;
    }

    void set_lin_exp(const lin_exp_program *_lin) {
        lin = _lin;
        type = LIN_EXP;
    }

    void set_var_type(int _var) {
        type = VAR;
        var = _var;
        all_parameters = _var >= 3;
    }
    void set_const_value(int _value) {
        type = CONST_VALUE;
        value = _value;
        all_parameters = true;
    }
    int get_op() const {
        return op;
    }
    atomic_term* get_arg() const {
        return arg;
    }
    atomic_term* get_arg_curry() const {
        return arg_curry;
    }
    int get_var() const {
        return var;
    }
    const lin_exp_program* getlin() const {
        return lin;
    }
    int get_value() const {
        return value;
    }

    bool get_all_parameter() const {
        return all_parameters;
    }

    void update_all_parameter(bool w) {
        all_parameters = w;
        if(all_parameters && arg)
            all_parameters &= arg->get_all_parameter();
        if(all_parameters && arg_curry)
            all_parameters &= arg_curry->get_all_parameter();
        if(all_parameters && lin)
            all_parameters &= false;
    }

    NonTerminalType get_type() const {
        return type;
    }

    witness_dsl* evaluate(witness_env* genv, const env* _env = nullptr);
};

enum LIN_EXP_TYPE {
    VALUE,
    EQ0,
    LE0
};

class lin_exp_program {
    atomic_term* coef;
    atomic_term* program;
    LIN_EXP_TYPE type;
public:

    lin_exp_program(atomic_term* u, atomic_term* v, int w) {
        coef = u;
        program = v;
        type = (LIN_EXP_TYPE) w;
    }

    witness_dsl* evaluate(witness_env* env) const {
        int coefficient = static_cast<witness_atom*>(coef->evaluate(env))->get_value();
        int value = static_cast<witness_atom*>(program->evaluate(env))->get_value();
        int ans = coefficient * value;
        if(type == LE0)
            ans = ans <= 0;
        if(type == EQ0)
            ans = ans == 0;
        return new witness_atom(ans);
    }

    atomic_term* get_coef() const {
        return coef;
    }

    atomic_term* get_program() const {
        return program;
    }

    LIN_EXP_TYPE get_type() const {
        return type;
    }
};

class list_map_list_list_to_list: public constructors {
    atomic_term* tm;
public:

    list_map_list_list_to_list(): constructors(true) {
        tm = new atomic_term;
    }

    void set_term(atomic_term* _tm) {
        tm = _tm;
    }

    void set_term_lin(const lin_exp_program* lin_exp) {
        tm->set_lin_exp(lin_exp);
    }

    witness_list* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        return nullptr;
        const auto& cur = static_cast<witness_list_list*>(input)->get_value();
        vector<int> res;
        auto* pp = new witness_atom;
        auto* qq = new witness_atom;
        genv->set(3, pp);
        genv->set(4, qq);
        for(int i = 0; i < cur.size(); i ++) {
            pp->set(i);
            qq->set(cur[i][0]);
            int u = static_cast<witness_atom*>(tm->evaluate(genv, _env))->get_value();
            res.push_back(u);
        }
        delete pp;
        delete qq;
        return new witness_list(res);
    }
};

class list_sum: public constructors {
public:
    witness_atom* evaluate(witness_env* genv, witness_dsl* input, witness_dsl* input_curry, const env* _env) const override {
        return nullptr;
        if(input->get_ty() != LIST)
            return nullptr;
        const vector<int>& cur = static_cast<witness_list*>(input)->get_value();
        int ans = 0;
        for(const auto&u: cur)
            ans += u;
        return new witness_atom(ans);
    }
};


typedef vector<atomic_term*> witness;
typedef vector<pair<term*, lin_exp_coef*> > closure_type;
typedef vector<vector<int> > vars_type;
typedef vector<pair<vars_type, closure_type> > synthesis_data_info;


class witness_solver {
    vector<example_info> datas;
    vector<computation_info> computes;
    vector<scheduler*> schedulers;
    vector<example*> concrete_problems;
    example* meta_problem;
    witness result;
public:
    witness_solver() {
        datas.clear();
        meta_problem = nullptr;
    }

    void set_meta(example* _ex) {
        meta_problem = _ex;
    }

    void add_info(example_info& w, computation_info & cinfo, scheduler* _s, example* ex) {
        datas.emplace_back(w);
        computes.push_back(cinfo);
        schedulers.emplace_back(_s);
        concrete_problems.emplace_back(ex);
    }

    void solve(long double &t);
    int check() const;
};



#endif //DPSYN_WITNESS_SYNTHEISZER_H
