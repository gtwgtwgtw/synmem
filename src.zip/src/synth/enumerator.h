//
// Created by gtw on 22-5-10.
//

#ifndef DPSYN_ENUMERATOR_H
#define DPSYN_ENUMERATOR_H

#include "semantics.h"

enum type{
	HEAD,
	TAIL,
};

class search_tree;

typedef pair<type, int> object;

class enumerator {
	enumerator* next;
	vector<object> var;
public:
	const vector<object>& get_var() const {
		return var;
	}
	enumerator* get_next() const {
		return next;
	};
	
	enumerator() = default;
	enumerator(enumerator* _next, vector<object>& _var):
		next(_next), var(std::move(_var)) {}
	enumerator(const enumerator &a) = default;
	enumerator(enumerator&& a) = default;
	~enumerator() {
		delete next;
		var.clear();
	}
};



#endif //DPSYN_ENUMERATOR_H