//
// Created by gtw on 22-5-5.
//

#include <iostream>
#include "syntax.h"

int constval::contains(int _name) const {
	return value == _name;
}

term* constval::deepcopy() const   {
	return new constval(value);
}

int atom_term::contains(int _name) const {
	int res = 0;
	for(const auto&u: oprands)
		res = res || u->contains(_name);
	return res;
}

term* atom_term::deepcopy() const {
	vector<term*> oprands_new;
	for(const auto& u: oprands)
		oprands_new.push_back(u->deepcopy());
	return new atom_term(f_op, oprands_new);
}

int reduce_term::contains(int _name) const {
	return 0;
}

term* reduce_term::deepcopy() const {
	term* n_body = reduce_body->deepcopy();
	term* n_func_range_l = func_range_l->deepcopy();
	term* n_func_range_r = func_range_r->deepcopy();
	auto* res = new reduce_term(f_op, n_func_range_l, n_func_range_r, range_var, n_body);
    if(flatten_body) {
        res->set_flatten();
        for(const auto& tm: bodies)
            res->add_term(tm);
    }
    return res;
}
