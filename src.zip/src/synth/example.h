//
// Created by gtw on 22-5-5.
//

#ifndef DPSYN_EXAMPLE_H
#define DPSYN_EXAMPLE_H

#include <random>
#include <cstring>
#include <iostream>

#include "semantics.h"
#include "enumerator.h"

enum labels{
	PARAMETER_VALUE,
	PARAMETER_LIST,
	VAR_LIST,
	VAR_VALUE,
	NUL
} ;

class example {
	int iden_num;
    int overhead;
    bool _type;
	labels label[IDEN_MAX * 2];
	string str_name[IDEN_MAX * 2];
	vector<term *> constraints;
	vector<int> var_value;
	vector<int> var_list;
	vector<int> length_var_list;
	vector<int> parameter_value;
	vector<int> parameter_list;
	vector<int> length_param_list;
	env *example_env;
public:
	example() {
		iden_num = 0;
        overhead = 1;
		for(int i = 0; i < IDEN_MAX * 2; i++) {
			str_name[i] = "";
			label[i] = NUL;
		}
		constraints.clear();
		var_value.clear();
		var_list.clear();
		length_var_list.resize(IDEN_MAX, 0);
		parameter_value.clear();
		parameter_list.clear();
		length_param_list.resize(IDEN_MAX, 0);
		example_env = new env();
        _type = false;
	}
	
	const env* get_env() const {  return example_env; }
	
	const vector<term*>& get_constraints() const {
		return constraints;
	}
	
	explicit example(env* e) {
		iden_num = 0;
        overhead = 1;
		for(int i = 0; i < IDEN_MAX * 2; i++) {
			str_name[i] = "";
			label[i] = NUL;
		}
		constraints.clear();
		var_value.clear();
		var_list.clear();
		length_var_list.resize(IDEN_MAX, 0);
		parameter_value.clear();
		parameter_list.clear();
		length_param_list.resize(IDEN_MAX, 0);
		example_env = e;
        _type = false;
	}
	
	virtual ~example() {
		delete example_env;
		for(auto u: constraints) {
			delete u;
		}
		constraints.clear();
		var_value.clear();
		var_list.clear();
		length_var_list.clear();
		parameter_value.clear();
		parameter_list.clear();
		length_param_list.clear();
	}
	
	example(const example& a):
	var_value(a.var_value),
	var_list(a.var_list),
	length_var_list(a.length_var_list),
	parameter_value(a.parameter_value),
	parameter_list(a.parameter_list),
	length_param_list(a.length_param_list),
    overhead(a.overhead),
	iden_num(a.iden_num){
		for(int i = 0; i < IDEN_MAX*2; i++) {
			str_name[i] = "";
			label[i] = NUL;
		}
		for(int i = 0; i < iden_num; i ++) label[i] = a.label[i];
		for(int i = 0; i < iden_num; i ++) str_name[i] = a.str_name[i];
		for(const auto& u: a.constraints) {
			constraints.push_back(u->deepcopy());
		}
		example_env = new env(*(a.example_env));
        _type = false;
	}
	example(example&& a) = default;
	
	int new_identifier(string name, domain dom) {
		iden_num++;
		example_env->update_domain(iden_num - 1, dom);
		str_name[iden_num - 1] = std::move(name);
		return iden_num - 1;
	}
	
	int new_parameter(string name, domain dom) {
		int kk = new_identifier(std::move(name), dom);
		parameter_value.push_back(kk);
		label[kk] = PARAMETER_VALUE;
		return kk;
	}
	
	int new_parameter_list(string name, int len, domain dom) {
		int kk = new_identifier(std::move(name), dom);
		parameter_list.push_back(kk);
//		puts("here");
		label[kk] = PARAMETER_LIST;
		length_param_list[kk] = len;
//		puts("here");
		return kk;
	}
	
	int new_var(string name, domain dom) {
		int kk = new_identifier(std::move(name), dom);
		var_value.push_back(kk);
		label[kk] = VAR_VALUE;
		return kk;
	}
	
	int new_var_list(string name, int len, domain dom) {
		int kk = new_identifier(std::move(name), dom);
		var_list.push_back(kk);
		label[kk] = VAR_LIST;
		length_var_list[kk] = len;
		return kk;
	}
	
	void update_env(int name, int value) {
		example_env->update_value(name, value);
	}
	
	void update_env_list_par(int name, int idx, int value) {
		example_env->update_list_par(name, idx, value);
	}
	
	void concretize();
	
	void solve();
	
	void collect();
	
	void add_constraint(term* u) {
		constraints.push_back(u);
	}
	
	labels get_label(int name) const { return label[name]; }
	int get_length(int name) const { return length_var_list[name]; }
	
	int env_lookup(int name) const {
		return example_env->lookup(name);
	}

    const vector<int>& get_var_value() const {
        return var_value;
    }

    const vector<int>& get_var_list() const {
        return var_list;
    }


    const vector<int>& get_param_list() const {
        return parameter_list;
    }

    const string& get_name(int id) const {
        return str_name[id];
    }


    int env_list_lookup(int name, int idx, int type) const {
		return example_env->list_lookup(name, idx, type);
	}
	
	void update_ord(int name, int value) {
		example_env->ord_update(name, value);
	}

    void update_domain(int name, domain dom) {
        example_env->update_domain(name, dom);
    }

	int ord_lookup(int name) const {
		return example_env->ord_lookup(name);
	}
	
	virtual example* generate() = 0;
    virtual enumerator * get_enumerator() const = 0;

    bool get_type() const {
        return _type;
    }
    void set_type() {
        _type = true;
    }

    void upd_overhead(int _ovhead) { overhead = _ovhead; }
    int get_overhead() const { return overhead; }
};

class bi_example {
public:
    example* ex;
    bool is_opt;

    bi_example (example* _ex, bool _is_opt) {
        ex = _ex;
        is_opt = _is_opt;
    }

    bi_example () { ex = nullptr; is_opt = false; }
};

typedef vector<bi_example> ex_factory;


#endif //DPSYN_EXAMPLE_H
