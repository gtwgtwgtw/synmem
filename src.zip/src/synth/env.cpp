//
// Created by gtw on 22-5-5.
//

#include "env.h"

int env::lookup(int name) const {
	if(name < 0 || name >= varid_to_value.size())
		return -INF;
	return varid_to_value[name];
}

domain env::domain_lookup(int name) const {
	if(name < 0 || name >= varid_to_value.size())
		return std::make_pair(-INF, -INF);
	return varid_to_domain[name];
}


const vector<int>& env::list_lookup(int list_name, int calltype) const {
    const vector<vector<int> >& cur_vec = mutex(calltype);
	fprintf(stderr, "lookup %d %d\n", list_name, calltype);
	if(list_name < 0 || list_name >= cur_vec.size())
		return cur_vec[0];
	
	return cur_vec[list_name];
}

int env::list_lookup(int list_name, int idx, int calltype) const {

#if DEBUG
	fprintf(stderr, "list_lookup %d %d %d\n", list_name, idx, calltype);
#endif
    const vector<vector<int> >& cur_vec = mutex(calltype);
	//fprintf(stderr, "size = %d\n", cur_vec.size());
	if(idx < 0 || list_name < 0 || list_name >= cur_vec.size())
		return -INF;
	const vector<int>& cur = cur_vec[list_name];
	if(idx >= cur.size())
		return -INF;
	
	return cur[idx];
}