//
// Created by gtw on 22-5-5.
//

#ifndef DPSYN_ENV_H
#define DPSYN_ENV_H

#include "core.h"
#include "syntax.h"
typedef pair<int,int> domain;
#define domain_min first
#define domain_max second

class env {
	vector<int> varid_to_value;
	vector<domain> varid_to_domain;
	vector<vector<int> > list_to_var_plus_value;
	vector<vector<int> > list_to_list;
	vector<vector<int> > list_to_value;
	vector<vector<int> > list_to_range;
	vector<int> varid_to_ord;
public:
	
	env() {
		varid_to_value.resize(IDEN_MAX, -INF);
		varid_to_domain.resize(IDEN_MAX, make_pair(-INF, INF));
		list_to_var_plus_value.resize(IDEN_MAX, {});
		list_to_list.resize(IDEN_MAX, {});
		list_to_value.resize(IDEN_MAX, {});
		list_to_range.resize(IDEN_MAX, {});
		varid_to_ord.resize(IDEN_MAX, -INF);
		for(int i = 0; i < IDEN_MAX; i ++) {
			list_to_var_plus_value[i].resize(IDEN_MAX, -INF);
			list_to_list[i].resize(IDEN_MAX, -INF);
			list_to_value[i].resize(IDEN_MAX, -INF);
			list_to_range[i].resize(IDEN_MAX, -INF);
		}
	}
	~env() {
		for(int i = 0; i < IDEN_MAX; i ++) {
			list_to_var_plus_value[i].clear();
			list_to_list[i].clear();
			list_to_value[i].clear();
			list_to_range[i].clear();
		}
		varid_to_value.clear();
		varid_to_domain.clear();
		list_to_var_plus_value.clear();
		list_to_list.clear();
		list_to_value.clear();
		list_to_range.clear();
		varid_to_ord.clear();
	}
	
	explicit env(const env &e):
	varid_to_value(e.varid_to_value),
	varid_to_domain(e.varid_to_domain),
	list_to_var_plus_value(e.list_to_var_plus_value),
	list_to_list(e.list_to_list),
	list_to_value(e.list_to_value),
	list_to_range(e.list_to_range),
	varid_to_ord(e.varid_to_ord)
	{ }
	
	int ord_lookup(int name) const { return varid_to_ord[name]; }
	void ord_update(int name, int _ord) {varid_to_ord[name] = _ord; }
	
	int lookup(int name) const;
	int list_lookup(int list_name, int idx, int calltype) const;
	domain domain_lookup(int name) const;
	const vector<int>& list_lookup(int list_name, int calltype) const;
	void update_value(int u, int v) {
		varid_to_value[u] = v;
	}
	void update_domain(int u, domain v) {
		//printf("update %d\n", u);
		varid_to_domain[u] = v;
	}
	void update_list_var(int list_name, int idx_name, int v) {
#if DEBUG
		fprintf(stderr, "update %d %d = %d", list_name, idx_name, v);
#endif
		list_to_var_plus_value[list_name][idx_name] = v;
	}
	void update_list_par(int list_name, int idx_name, int v) {
		list_to_value[list_name][idx_name] = v;
	}

    const vector<vector<int> >& mutex(int u) const {
//        fprintf(stderr, "type = %d %d\n", u, u + 1);
        if(u == 1)
            return list_to_var_plus_value;
        if(u == 2)
            return list_to_list;
        if(u == 3)
            return list_to_value;
        return list_to_range;
    }
};

#endif //DPSYN_ENV_H
