//
// Created by gtw on 22-5-6.
//

#include <iostream>
#include "example.h"


void example::concretize() {
	for(auto& u: length_param_list) {
		if(ISVAR(u)) {
			int var_name = VALUE_TO_VAR(u);
			int value = example_env->lookup(var_name);
			u = value;
		}
	}

	for(auto& u: length_var_list) {
		if(ISVAR(u)) {
			int var_name = VALUE_TO_VAR(u);
			int value = example_env->lookup(var_name);
			u = value;
		}
	}
	
	for(int u = 0; u < iden_num; u ++) {
		domain cur_dom = example_env->domain_lookup(u);
		if(ISVAR(cur_dom.second)) {
			int var_name = VALUE_TO_VAR(cur_dom.second);
			int value = example_env->lookup(var_name);
			example_env->update_domain(u, std::make_pair(cur_dom.first, value));
		}
	}
	
	
	for(const auto&u: var_list) {
#if DEBUG
		fprintf(stderr, "varlist: id = %d, len = %d\n", u, length_var_list[u]);
#endif
		domain cur_dom = example_env->domain_lookup(u);
		for(int j = 0; j < length_var_list[u]; j ++) {
			char name[35];
			sprintf(name, "var_list_%d_%d", u, j);
			int iden = new_var(name, cur_dom);
			example_env->update_list_var(u, j, iden + INF);
		}
	}
	
	
	vector<term*> new_constraints;
	
	for(const auto&u: constraints) {
		auto reduced_u = dynamic_cast<reduce_term*>(u);
		if(reduced_u == nullptr) {
			new_constraints.emplace_back(u);
			continue;
		}
#if DEBUG
        fprintf(stderr, "[CONSIDER CONSTRAINT]\n");
        reduced_u->get_body()->print();
        fprintf(stderr, "\n");
#endif
		if(reduced_u->get_operator() == string_to_op("And")) {
			vector<term*> res = reduced_u->transform(example_env);
            if(res.empty()) {
                new_constraints.emplace_back(u);
                continue;
            }
			for(const auto&v: res)
				new_constraints.emplace_back(v);
			delete reduced_u;
            continue;
		}
        new_constraints.emplace_back(u);
	}

	constraints.resize(new_constraints.size(), nullptr);
	for(int i = 0; i < new_constraints.size(); i ++) {
		constraints[i] = new_constraints[i];
#if DEBUG
		constraints[i]->print();
		std::cerr << std::endl;
#endif
	}
}

void example::solve() {

}